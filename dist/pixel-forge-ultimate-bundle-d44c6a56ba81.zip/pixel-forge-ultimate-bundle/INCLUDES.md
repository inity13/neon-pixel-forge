# Pixel Forge Ultimate Bundle — Complete Contents

## All 10 Products Included

1. **dungeon-tileset/** — Dungeon Tileset ($3)
   - 200+ unique 16×16 dungeon tiles
   - Floors, walls, doors, traps, decorations, water, lava, stairs

2. **explosion-vfx-pack/** — Explosion VFX Pack ($3)
   - 6 explosion types with 46 animation frames
   - Fire, plasma, smoke, sparks, energy ring, pixel shatter

3. **monster-bestiary-pack/** — Monster Bestiary Pack ($5)
   - Full monster sprite collection with animations
   - Idle, attack, death animations per monster

4. **nature-tileset-mega/** — Nature Tileset Mega ($5)
   - Complete outdoor/nature tileset
   - Trees, grass, water, mountains, weather effects

5. **pixel-font-pack/** — Pixel Font Pack ($3)
   - 3 pixel fonts (Regular, Bold, Handwritten)
   - Full character set (A-Z, a-z, 0-9, punctuation)

6. **pixel-weapons-collection/** — Pixel Weapons Collection ($3)
   - Swords, axes, bows, staves, shields
   - Each with idle and attack animation frames

7. **retro-platformer-kit/** — Retro Platformer Kit ($5)
   - NES-style player, enemies, items, tiles
   - Full platformer level building kit

8. **sci-fi-ui-kit/** — Sci-Fi UI Kit ($5)
   - Buttons, panels, health bars, minimaps
   - Sci-fi themed interface elements

9. **space-shooter-assets/** — Space Shooter Assets ($3)
   - Player ships, enemies, asteroids, projectiles
   - Power-ups, explosions, star backgrounds

10. **warrior-sprite-pack/** — Warrior Sprite Pack ($3)
    - Warrior character with full animation set
    - Idle, walk, run, attack, death animations

## Total Individual Value: $38
## Bundle Price: $19 (50% savings)
