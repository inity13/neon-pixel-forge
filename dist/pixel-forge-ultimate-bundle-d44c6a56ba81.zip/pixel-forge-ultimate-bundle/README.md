# 👑 Pixel Forge Ultimate Bundle

**Every single Pixel Forge asset pack in one massive collection. The complete game asset library.**

> Save 50%+ vs buying individually ($19 vs $39)

## What's Included

| # | Product | Individual Price | Description |
|---|---------|-----------------|-------------|
| 1 | [Dungeon Tileset](../dungeon-tileset/) | $3 | 200+ dungeon tiles (16×16) |
| 2 | [Explosion VFX Pack](../explosion-vfx-pack/) | $3 | 6 animated explosion types |
| 3 | [Monster Bestiary Pack](../monster-bestiary-pack/) | $5 | Monster sprites with animations |
| 4 | [Nature Tileset Mega](../nature-tileset-mega/) | $5 | Outdoor/nature tileset |
| 5 | [Pixel Font Pack](../pixel-font-pack/) | $3 | 3 complete pixel fonts |
| 6 | [Pixel Weapons Collection](../pixel-weapons-collection/) | $3 | Weapon sprites |
| 7 | [Retro Platformer Kit](../retro-platformer-kit/) | $5 | NES-style platformer assets |
| 8 | [Sci-Fi UI Kit](../sci-fi-ui-kit/) | $5 | Sci-fi interface elements |
| 9 | [Space Shooter Assets](../space-shooter-assets/) | $3 | Space shooter sprites |
| 10 | [Warrior Sprite Pack](../warrior-sprite-pack/) | $3 | Warrior character sprites |
| | **Total Individual** | **$38** | |
| | **Bundle Price** | **$19** | **Save $19 (50%)** |

## Perfect For

- 🎮 Indie game studios building multiple games
- 🏆 Game jam veterans who need variety
- 🎓 Schools and coding bootcamps
- 💎 Collectors who want the complete set

## How It Works

1. Purchase the ultimate bundle via Neon Bazaar
2. Download the massive ZIP containing all 10 product packs
3. Each pack is in its own folder — fully self-contained
4. Mix and match assets across projects (all MIT licensed)

## License

MIT License — use in personal and commercial projects. See LICENSE file.
