# How to Use Pixel Forge Assets in Your Game Engine

## Godot Engine (3.5+ / 4.x)

### Importing Sprites

1. **Copy files** into your Godot project's `res://sprites/` directory
2. **SVG Import**: Godot imports SVGs natively. Set import preset to "2D Pixel" to disable filtering
3. **PPM Import**: Convert to PNG first (see below), then import into Godot
4. **JSON Animation Data**: Parse with `JSON.parse_string()` (Godot 4) or `JSON.parse()` (Godot 3)

### Setting Up AnimatedSprite2D (Godot 4)

```gdscript
# Load sprite sheet and create SpriteFrames from animation_data.json
var sprite_sheet = preload("res://sprites/warrior_sprites.svg")
var anim_data = JSON.parse_string(FileAccess.open("res://sprites/animation_data.json", FileAccess.READ).get_as_text())

# Configure in the Inspector:
# 1. Create new SpriteFrames resource
# 2. For each animation in anim_data:
#    - Add animation with matching name
#    - Set frame count and FPS from frame_duration_ms
#    - Assign atlas regions from the sprite sheet
```

### Configuring Pixel-Perfect Rendering

```
Project > Project Settings > Rendering > Textures:
  Default Texture Filter: Nearest
  
Window > Stretch:
  Mode: canvas_items (or viewport)
  Aspect: keep
```

## Unity (2021+)

### Importing Sprites

1. **Convert SVG to PNG** using any image editor (or the included `generate_ppm.py`)
2. **Import PNG** into your `Assets/Sprites/` folder
3. In the **Sprite Import Settings**:
   - Texture Type: Sprite (2D and UI)
   - Sprite Mode: Multiple
   - Pixels Per Unit: 32 (or 16, depending on your scale)
   - Filter Mode: **Point (no filter)** ← CRITICAL for pixel art
   - Compression: None

### Slicing the Sprite Sheet

```
Sprite Editor > Slice:
  Type: Grid by Cell Size
  Pixel Size: 32 x 32
  Padding: 0
  
Then assign frames to Animation Clips in the Animator.
```

### Using animation_data.json

```csharp
// Parse the JSON to set up animation clips
using UnityEngine;
using System.IO;

[System.Serializable]
public class AnimationDef {
    public int frames;
    public int frame_duration_ms;
    public bool loop;
}

// Load: var json = File.ReadAllText("path/to/animation_data.json");
// Parse: var data = JsonUtility.FromJson<Dictionary<string, AnimationDef>>(json);
```

## Web (HTML5 Canvas / JavaScript)

### Loading Sprites

```javascript
// Option 1: Load SVG directly
const img = new Image();
img.src = 'warrior_sprites.svg';
img.onload = () => {
    // Draw to canvas with imageSmoothingEnabled = false
    ctx.imageSmoothingEnabled = false;
    ctx.drawImage(img, srcX, srcY, 32, 32, destX, destY, 64, 64);
};

// Option 2: Use the CSS pixel art (preview/index.html)
// Each pixel is a CSS box-shadow — great for web-native projects

// Option 3: Load animation data
fetch('animation_data.json')
    .then(r => r.json())
    .then(data => {
        // data.idle.frames = 4
        // data.idle.frame_duration_ms = 200
        // Use with requestAnimationFrame loop
    });
```

### Pixel-Perfect Scaling

```css
canvas {
    image-rendering: pixelated;           /* Chrome */
    image-rendering: crisp-edges;         /* Firefox */
    -ms-interpolation-mode: nearest-neighbor; /* IE */
}
```

## Converting PPM to PNG

The included `generate_ppm.py` outputs Portable Pixmap files (.ppm). To convert:

### Using ImageMagick (command line)
```bash
convert warrior_idle.ppm warrior_idle.png
```

### Using GIMP
1. File > Open > select the .ppm file
2. File > Export As > choose PNG format

### Using Python (with Pillow — NOT included, you install separately)
```bash
pip install Pillow
python3 -c "from PIL import Image; Image.open('warrior_idle.ppm').save('warrior_idle.png')"
```

### Online Converters
- https://convertio.co/ppm-png/
- https://cloudconvert.com/ppm-to-png

## Tiled Map Editor Integration

For tileset products, the JSON tilemaps are compatible with **Tiled** (https://www.mapeditor.org/):

1. Open Tiled
2. File > Open > select the `.json` tilemap file
3. The tileset reference will auto-load if the image is in the same directory
4. Edit the map and re-export to your game engine's format

## General Tips

- **Always disable texture filtering** for pixel art. Bilinear/trilinear filtering will blur your sprites.
- **Scale by integer multiples** (2x, 3x, 4x) to keep pixels crisp. Non-integer scaling causes shimmer.
- **Use the palette.json** to match your custom assets to the same color scheme.
- **Animation JSON format** is consistent across all Pixel Forge products — learn it once, use everywhere.
