# 🚀 Space Shooter Assets

**16×16 and 32×32 space shooter sprites with ships, enemies, asteroids, projectiles, power-ups, and effects.**

```
         /\
        /  \
       / ++ \          ★  .    ★
      / /  \ \     .        ★
     / / ++ \ \        .    .
    /_/  ||  \_\   ★     .
   |  |__||__|  |       ★
   |  /_/  \_\  |   .        .
   |_/ |    | \_|     ★   ★
     |_|    |_|    .     .
      ╚══════╝         ★
   SPACE SHOOTER ASSETS
```

## What's Included

| Category       | Count | Sizes   | Description |
|----------------|-------|---------|-------------|
| Player Ships   | 3     | 24–32px | Fighter, bomber, scout with engine glow |
| Enemy Ships    | 4     | 16–64px | Drone, cruiser, carrier, boss |
| Asteroids      | 4     | 16–48px | Small (2 variants), medium, large |
| Projectiles    | 5     | 8×8–16  | Lasers, plasma, missiles, energy balls |
| Power-Ups      | 4     | 16×16   | Shield, speed, weapon upgrade, health |
| Effects        | 3     | 16–32px | Explosions (small/large), shield hit |
| **Total**      | **23**|         | |

## File Structure

```
space-shooter-assets/
├── README.md              ← You are here
├── USAGE.md               ← Integration guides (Godot, Unity, Web)
├── LICENSE                 ← MIT License
├── palette.json           ← Color palette (16 colors, neon sci-fi)
├── src/
│   ├── ship_data.json     ← Ship & enemy metadata (sizes, hitboxes, frames)
│   ├── projectile_data.json ← Projectile, power-up & effect definitions
│   └── generate_ships.py  ← Python SVG generator (stdlib only)
├── preview/
│   └── index.html         ← Static sprite gallery (all assets by category)
├── demo/
│   └── index.html         ← Interactive space scene (mouse + click to shoot)
└── examples/
```

## Quick Start

1. Open `preview/index.html` to see every sprite organized by category
2. Open `demo/index.html` for an interactive space shooter scene
3. Run `python3 src/generate_ships.py` to generate SVG files from pixel data

## Generate SVGs

```bash
cd src/
python3 generate_ships.py
# Outputs individual sprite SVGs and combined sprite sheets
```

## Color Palette

| Color | Hex | Usage |
|-------|-----|-------|
| Space Void | `#06060c` | Deep space background |
| Space Dark | `#0e0e1a` | Dark space, nebula base |
| Hull Gray | `#5a5a6e` | Ship hull, metal |
| Hull Light | `#8a8a9e` | Hull highlights, cockpit trim |
| Engine Blue | `#2244cc` | Engine core, thrust |
| Engine Cyan | `#00ccff` | Engine glow, afterburner |
| Laser Green | `#00ff66` | Player laser projectiles |
| Laser Red | `#ff2244` | Enemy laser projectiles |
| Plasma Purple | `#9944ff` | Plasma weapons, effects |
| Plasma Pink | `#ff44cc` | Plasma glow, trails |
| Shield Blue | `#4488ff` | Shield effect, power-up |
| Asteroid Dark | `#4a3a2a` | Asteroid shadow, craters |
| Asteroid Light | `#7a6a5a` | Asteroid surface highlights |
| Explosion Orange | `#ff6622` | Explosion core, fire |
| Explosion Yellow | `#ffcc22` | Explosion bright center |
| Star White | `#ffffff` | Stars, highlights, UI text |

## Sprite Properties

Each entry in `src/ship_data.json` and `src/projectile_data.json` includes:

- `name`: Human-readable name
- `size`: `[width, height]` in pixels
- `frames`: Number of animation frames
- `frame_duration_ms`: Animation speed per frame
- `hitbox`: `{ "x": n, "y": n, "w": n, "h": n }` — collision rectangle
- `category`: ship, enemy, asteroid, projectile, powerup, or effect

## Integration Tips

- Use `additive` blend mode for engine glows, lasers, and explosions
- Layer shield effects on top of the ship sprite
- Scale by integer multiples (2×, 3×, 4×) for crisp pixels
- Combine small + large explosions for dramatic destruction sequences
- Enemy ships use red/purple tones, player ships use blue/cyan — keep this convention

## License

MIT License — use in personal and commercial projects. See LICENSE file.
