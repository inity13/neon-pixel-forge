# Retro Platformer Kit

**Complete NES-style platformer asset pack with 16x16 and 32x32 sprites for classic side-scrolling action games.**

```
  ╔═══════════════════════════════════════════════╗
  ║  [P]    *    ♦         ░░░░░░░░░░             ║
  ║ /|\ ───────       ════════════════            ║
  ║ / \   ~^~  S      ▓▓▓▓▓▓▓▓▓▓▓▓▓▓            ║
  ║════════════════    ▒▒▒▒▒▒▒▒▒▒▒▒▒▒ ♠  ▲       ║
  ║▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓ ║
  ╚═══════════════════════════════════════════════╝
               Retro Platformer Kit
```

## What's Included

| Category         | Sprites | Size  | Description |
|------------------|---------|-------|-------------|
| Player Idle      | 2       | 32×32 | Standing animation (breathing cycle) |
| Player Run       | 4       | 32×32 | Full run cycle with arm/leg movement |
| Player Jump      | 2       | 32×32 | Jump ascent and descent poses |
| Enemy: Slime     | 2       | 16×16 | Bouncing blob with squash/stretch |
| Enemy: Bat       | 4       | 16×16 | Flapping wing cycle |
| Enemy: Skeleton  | 4       | 16×16 | Walking patrol animation |
| Enemy: Ghost     | 2       | 16×16 | Hovering fade in/out |
| Coin             | 4       | 16×16 | Spinning coin rotation |
| Gem              | 2       | 16×16 | Sparkling gem pulse |
| Heart            | 1       | 16×16 | Health pickup |
| Star             | 1       | 16×16 | Invincibility star |
| Terrain Tiles    | 5       | 16×16 | Grass, dirt, stone, brick (seamless) |
| Background Tiles | 5       | 16×16 | Clouds, bush, tree |
| Interactive       | 3       | 16×16 | Question block, breakable, spikes |
| Decorations      | 3       | 16×16 | Flower, mushroom, sign post |
| **Total**        | **44**  |       | |

## File Structure

```
retro-platformer-kit/
├── README.md               ← You are here
├── USAGE.md                ← Integration guides (Godot, Unity, Web)
├── LICENSE                 ← MIT License
├── palette.json            ← Color palette (16 colors, NES-inspired)
├── src/
│   ├── sprite_data.json    ← Sprite metadata (frames, timing, sizes)
│   ├── tileset_data.json   ← Platform tile definitions
│   └── generate_sprites.py ← Python SVG generator (stdlib only)
├── preview/
│   └── index.html          ← Static gallery of all sprites and tiles
├── demo/
│   └── index.html          ← Interactive platformer level viewer
└── examples/
```

## Quick Start

1. Open `preview/index.html` to see every sprite and tile in the pack
2. Open `demo/index.html` for an interactive platformer level demo
3. Run `python3 src/generate_sprites.py` to generate SVG files from pixel data

## Generate SVGs

```bash
cd src/
python3 generate_sprites.py
# Outputs individual sprite SVGs and combined sprite sheets
```

## Color Palette

| Color | Hex | Usage |
|-------|-----|-------|
| Sky Light | `#6888ff` | Background sky upper |
| Sky Dark | `#3050c0` | Background sky lower |
| Ground Light | `#c8b060` | Sand / light terrain |
| Ground Dark | `#886830` | Dirt / dark terrain |
| Player Primary | `#d03030` | Hero main color (red) |
| Player Secondary | `#f0a040` | Hero accent (orange/skin) |
| Enemy Red | `#c02020` | Red enemy accents |
| Enemy Blue | `#4060d0` | Blue enemy accents |
| Coin Gold | `#f0c020` | Coin / gold collectibles |
| Gem Green | `#30b050` | Gem / green collectibles |
| Brick | `#a05020` | Brick blocks |
| Brick Light | `#c07040` | Brick highlights |
| Outline | `#181020` | Dark outlines |
| Leaf Green | `#40a030` | Vegetation / leaves |
| Trunk Brown | `#704020` | Tree trunks / wood |
| Cloud White | `#f0f0f0` | Clouds / highlights |

## Sprite Properties

Each sprite in `src/sprite_data.json` includes:
- `name`: Human-readable sprite name
- `size`: Pixel dimensions (16 or 32)
- `frames`: Number of animation frames
- `frame_duration_ms`: Milliseconds per frame
- `loop`: Whether the animation loops

Each tile in `src/tileset_data.json` includes:
- `name`: Tile identifier
- `category`: terrain, background, interactive, decoration
- `size`: Always 16×16
- `collision`: Whether the tile blocks movement
- `animated`: Whether the tile has animation frames

## License

MIT License — use in personal and commercial projects. See LICENSE file.
