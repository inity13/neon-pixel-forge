#!/usr/bin/env python3
"""
Retro Platformer Kit — Sprite & Tile Generator — Pixel Forge
Generates 16x16 and 32x32 NES-style platformer sprites as SVG pixel art.

Each sprite is defined as a character grid where each character maps to a
color in the NES-inspired palette. Outputs individual SVGs and combined sheets.

Usage:
    python3 generate_sprites.py
"""

import json
import os
from typing import Optional

# ─── NES-Inspired Palette ─────────────────────────────────────────────────────
PALETTE: dict[str, Optional[str]] = {
    "_": None,           # transparent
    "O": "#181020",      # outline
    "R": "#d03030",      # player primary (red)
    "A": "#f0a040",      # player secondary (orange/skin)
    "r": "#c02020",      # enemy red
    "B": "#4060d0",      # enemy blue
    "G": "#f0c020",      # coin gold
    "g": "#30b050",      # gem green
    "K": "#a05020",      # brick
    "k": "#c07040",      # brick light
    "L": "#40a030",      # leaf green
    "T": "#704020",      # trunk brown
    "W": "#f0f0f0",      # cloud white / highlights
    "S": "#6888ff",      # sky light
    "s": "#3050c0",      # sky dark
    "D": "#886830",      # ground dark
    "d": "#c8b060",      # ground light
}

# ═══════════════════════════════════════════════════════════════════════════════
# PLAYER SPRITES (32×32)
# ═══════════════════════════════════════════════════════════════════════════════

PLAYER_SPRITES = {
    # ─── Idle Frame 0: Standing straight ──────────────────────────────
    "player_idle_f0": [
        "________________________________",
        "________________________________",
        "________________________________",
        "________________________________",
        "___________OOOOOO_______________",
        "__________ORRRRRRO______________",
        "__________ORRRRRRO______________",
        "__________ORRRRRRRO_____________",
        "___________OOOOOO_______________",
        "__________OAAAAAO______________",
        "_________OOAAAAOO______________",
        "_________OAAOAOAAO_____________",
        "________ORRRRRRRRRO_____________",
        "________ORRRRRRRRRO_____________",
        "________ORRRRRRRRRO_____________",
        "________ORRRRRRRRRO_____________",
        "________ORRRRRRRRRO_____________",
        "_________ORRRRRRRO______________",
        "_________ORRRRRRRO______________",
        "__________ORRRRO________________",
        "__________OAAAAO________________",
        "_________OAAAAAO________________",
        "_________OAO__OAO_______________",
        "________OAO____OAO______________",
        "________OAO____OAO______________",
        "________OOO____OOO______________",
        "________OKKO___OKKO_____________",
        "________OKKO___OKKO_____________",
        "________OOOO___OOOO_____________",
        "________________________________",
        "________________________________",
        "________________________________",
    ],
    # ─── Idle Frame 1: Slight bob ─────────────────────────────────────
    "player_idle_f1": [
        "________________________________",
        "________________________________",
        "________________________________",
        "________________________________",
        "________________________________",
        "___________OOOOOO_______________",
        "__________ORRRRRRO______________",
        "__________ORRRRRRO______________",
        "__________ORRRRRRRO_____________",
        "___________OOOOOO_______________",
        "__________OAAAAAO______________",
        "_________OOAAAAOO______________",
        "_________OAAOAOAAO_____________",
        "________ORRRRRRRRRO_____________",
        "________ORRRRRRRRRO_____________",
        "________ORRRRRRRRRO_____________",
        "________ORRRRRRRRRO_____________",
        "________ORRRRRRRRRO_____________",
        "_________ORRRRRRRO______________",
        "_________ORRRRRRRO______________",
        "__________ORRRRO________________",
        "__________OAAAAO________________",
        "_________OAAAAAO________________",
        "_________OAO__OAO_______________",
        "________OAO____OAO______________",
        "________OAO____OAO______________",
        "________OOO____OOO______________",
        "________OKKO___OKKO_____________",
        "________OKKO___OKKO_____________",
        "________OOOO___OOOO_____________",
        "________________________________",
        "________________________________",
    ],
    # ─── Run Frame 0: Right foot forward ──────────────────────────────
    "player_run_f0": [
        "________________________________",
        "________________________________",
        "________________________________",
        "________________________________",
        "___________OOOOOO_______________",
        "__________ORRRRRRO______________",
        "__________ORRRRRRO______________",
        "__________ORRRRRRRO_____________",
        "___________OOOOOO_______________",
        "__________OAAAAAO______________",
        "_________OOAAAAOO______________",
        "_________OAAOAOAAO_____________",
        "________ORRRRRRRRRO_____________",
        "________ORRRRRRRRRO_____________",
        "_______ORRRRRRRRRRRO____________",
        "______OAORRRRRRRRRO_____________",
        "______OAORRRRRRRRRO_____________",
        "________ORRRRRRRRRO_____________",
        "_________ORRRRRRRO______________",
        "__________OAAAAO________________",
        "________OOAO_OAOO_______________",
        "_______OAO____OAO_______________",
        "______OAO______OAO______________",
        "______OOO_____OAO_______________",
        "______OKKO____OOO_______________",
        "_______OOO____OKKO______________",
        "_______________OOO______________",
        "________________________________",
        "________________________________",
        "________________________________",
        "________________________________",
        "________________________________",
    ],
    # ─── Run Frame 1: Passing position ────────────────────────────────
    "player_run_f1": [
        "________________________________",
        "________________________________",
        "________________________________",
        "___________OOOOOO_______________",
        "__________ORRRRRRO______________",
        "__________ORRRRRRO______________",
        "__________ORRRRRRRO_____________",
        "___________OOOOOO_______________",
        "__________OAAAAAO______________",
        "_________OOAAAAOO______________",
        "_________OAAOAOAAO_____________",
        "________ORRRRRRRRRO_____________",
        "________ORRRRRRRRRO_____________",
        "______OAORRRRRRRRROAO___________",
        "______OAORRRRRRRRROAO___________",
        "________ORRRRRRRRRO_____________",
        "_________ORRRRRRRO______________",
        "_________ORRRRRRRO______________",
        "__________OAAAAO________________",
        "_________OAAAAAO________________",
        "_________OAO_OAO________________",
        "________OAO___OAO_______________",
        "________OOO___OOO_______________",
        "________OKKO__OKKO______________",
        "________OOOO__OOOO______________",
        "________________________________",
        "________________________________",
        "________________________________",
        "________________________________",
        "________________________________",
        "________________________________",
        "________________________________",
    ],
    # ─── Run Frame 2: Left foot forward ───────────────────────────────
    "player_run_f2": [
        "________________________________",
        "________________________________",
        "________________________________",
        "________________________________",
        "___________OOOOOO_______________",
        "__________ORRRRRRO______________",
        "__________ORRRRRRO______________",
        "__________ORRRRRRRO_____________",
        "___________OOOOOO_______________",
        "__________OAAAAAO______________",
        "_________OOAAAAOO______________",
        "_________OAAOAOAAO_____________",
        "________ORRRRRRRRRO_____________",
        "________ORRRRRRRRRO_____________",
        "________ORRRRRRRRRRO____________",
        "________ORRRRRRRROAO____________",
        "________ORRRRRRRROAO____________",
        "________ORRRRRRRRRO_____________",
        "_________ORRRRRRRO______________",
        "__________OAAAAO________________",
        "_________OOAO_OAOO______________",
        "________OAO____OAO______________",
        "_______OAO______OAO_____________",
        "______OAO_______OOO_____________",
        "______OOO______OKKO_____________",
        "______OKKO______OOO_____________",
        "_______OOO___________________________",
        "________________________________",
        "________________________________",
        "________________________________",
        "________________________________",
        "________________________________",
    ],
    # ─── Run Frame 3: Other passing position ──────────────────────────
    "player_run_f3": [
        "________________________________",
        "________________________________",
        "________________________________",
        "___________OOOOOO_______________",
        "__________ORRRRRRO______________",
        "__________ORRRRRRO______________",
        "__________ORRRRRRRO_____________",
        "___________OOOOOO_______________",
        "__________OAAAAAO______________",
        "_________OOAAAAOO______________",
        "_________OAAOAOAAO_____________",
        "________ORRRRRRRRRO_____________",
        "________ORRRRRRRRRO_____________",
        "_____OAORRRRRRRRROAO____________",
        "_____OAORRRRRRRRROAO____________",
        "________ORRRRRRRRRO_____________",
        "_________ORRRRRRRO______________",
        "_________ORRRRRRRO______________",
        "__________OAAAAO________________",
        "_________OAAAAAO________________",
        "________OAO__OAO________________",
        "________OAO__OAO________________",
        "________OOO__OOO________________",
        "________OKKO_OKKO_______________",
        "________OOOO_OOOO_______________",
        "________________________________",
        "________________________________",
        "________________________________",
        "________________________________",
        "________________________________",
        "________________________________",
        "________________________________",
    ],
    # ─── Jump Frame 0: Ascending ──────────────────────────────────────
    "player_jump_f0": [
        "________________________________",
        "________________________________",
        "___________OOOOOO_______________",
        "__________ORRRRRRO______________",
        "__________ORRRRRRO______________",
        "__________ORRRRRRRO_____________",
        "___________OOOOOO_______________",
        "__________OAAAAAO______________",
        "_________OOAAAAOO______________",
        "_________OAAOAOAAO_____________",
        "_____OAORRRRRRRRROAO____________",
        "_____OAORRRRRRRRROAO____________",
        "________ORRRRRRRRRO_____________",
        "________ORRRRRRRRRO_____________",
        "________ORRRRRRRRRO_____________",
        "_________ORRRRRRRO______________",
        "_________ORRRRRRRO______________",
        "__________OAAAAO________________",
        "_________OAAAAAO________________",
        "________OAO___OAO_______________",
        "________OAO___OAO_______________",
        "_______OOO_____OOO______________",
        "_______OKKO____OKKO_____________",
        "________OOO_____OOO_____________",
        "________________________________",
        "________________________________",
        "________________________________",
        "________________________________",
        "________________________________",
        "________________________________",
        "________________________________",
        "________________________________",
    ],
    # ─── Jump Frame 1: Descending ─────────────────────────────────────
    "player_jump_f1": [
        "________________________________",
        "________________________________",
        "________________________________",
        "___________OOOOOO_______________",
        "__________ORRRRRRO______________",
        "__________ORRRRRRO______________",
        "__________ORRRRRRRO_____________",
        "___________OOOOOO_______________",
        "__________OAAAAAO______________",
        "_________OOAAAAOO______________",
        "_________OAAOAOAAO_____________",
        "________ORRRRRRRRRO_____________",
        "________ORRRRRRRRRO_____________",
        "________ORRRRRRRRRO_____________",
        "________ORRRRRRRRRO_____________",
        "________ORRRRRRRRRO_____________",
        "_________ORRRRRRRO______________",
        "_________ORRRRRRRO______________",
        "__________OAAAAO________________",
        "______OAOOAAAAAO________________",
        "______OAO_OAO_OAO_______________",
        "________OOAO___OAOO_____________",
        "________OKKO___OKKO_____________",
        "_________OOO____OOO_____________",
        "________________________________",
        "________________________________",
        "________________________________",
        "________________________________",
        "________________________________",
        "________________________________",
        "________________________________",
        "________________________________",
    ],
}

# ═══════════════════════════════════════════════════════════════════════════════
# ENEMY SPRITES (16×16)
# ═══════════════════════════════════════════════════════════════════════════════

ENEMY_SPRITES = {
    # ─── Slime Frame 0: Normal ────────────────────────────────────────
    "enemy_slime_f0": [
        "________________",
        "________________",
        "________________",
        "________________",
        "________________",
        "____OOOOOOOO____",
        "___Ogggggggg0___",
        "___OgWOggWOgO___",
        "___OggggggggO___",
        "___OggggggggO___",
        "___OggOOOOggO___",
        "___OggggggggO___",
        "___OggggggggO___",
        "____OOOOOOOO____",
        "________________",
        "________________",
    ],
    # ─── Slime Frame 1: Squashed ──────────────────────────────────────
    "enemy_slime_f1": [
        "________________",
        "________________",
        "________________",
        "________________",
        "________________",
        "________________",
        "________________",
        "___OOOOOOOOOO___",
        "__OggggggggggO__",
        "__OgWOggggWOgO__",
        "__OggggggggggO__",
        "__OgggOOOOgggO__",
        "__OggggggggggO__",
        "__OOOOOOOOOOOO__",
        "________________",
        "________________",
    ],
    # ─── Bat Frame 0: Wings up ────────────────────────────────────────
    "enemy_bat_f0": [
        "________________",
        "__O__________O__",
        "_OBO________OBO_",
        "_OBBO______OBBO_",
        "_OBBBO____OBBBO_",
        "_OBBBOOOOOOBBBO_",
        "__OBBBBrrBBBBO__",
        "__OBBBrWWrBBBO__",
        "___OBBBrrBBBO___",
        "____OBBBBBO_____",
        "_____OBBBO______",
        "______OOO_______",
        "________________",
        "________________",
        "________________",
        "________________",
    ],
    # ─── Bat Frame 1: Wings mid-up ────────────────────────────────────
    "enemy_bat_f1": [
        "________________",
        "________________",
        "________________",
        "__OO________OO__",
        "_OBBO______OBBO_",
        "_OBBBOOOOOOBBO__",
        "__OBBBBrrBBBBO__",
        "__OBBBrWWrBBBO__",
        "___OBBBrrBBBO___",
        "____OBBBBBO_____",
        "_____OBBBO______",
        "______OOO_______",
        "________________",
        "________________",
        "________________",
        "________________",
    ],
    # ─── Bat Frame 2: Wings mid-down ──────────────────────────────────
    "enemy_bat_f2": [
        "________________",
        "________________",
        "________________",
        "________________",
        "________________",
        "__OOOOOOOOOOOO__",
        "__OBBBBrrBBBBO__",
        "__OBBBrWWrBBBO__",
        "_OOBBBRRBBBOOO__",
        "_OBBOBBBBBOBBOO_",
        "__OBO_OBBBO_OBO_",
        "___O___OOO___O__",
        "________________",
        "________________",
        "________________",
        "________________",
    ],
    # ─── Bat Frame 3: Wings down ──────────────────────────────────────
    "enemy_bat_f3": [
        "________________",
        "________________",
        "________________",
        "________________",
        "________________",
        "__OOOOOOOOOOOO__",
        "__OBBBBrrBBBBO__",
        "__OBBBrWWrBBBO__",
        "__OOBBBrrBBBOO__",
        "__OBOBBBBBOBOBO_",
        "___OBBO_OBBOO___",
        "___OBBO__OBBO___",
        "____OO____OO____",
        "________________",
        "________________",
        "________________",
    ],
    # ─── Skeleton Frame 0: Stand ──────────────────────────────────────
    "enemy_skeleton_f0": [
        "________________",
        "________________",
        "_____OOOO_______",
        "____OWWWWO______",
        "____OWOWWO______",
        "____OWWWWO______",
        "_____OWWO_______",
        "______OO________",
        "____OWWWWO______",
        "___OOWWWWOO_____",
        "__OW_OWWO_WO____",
        "_OW___OO___WO___",
        "______WW________",
        "_____OWWO_______",
        "____OW__WO______",
        "____OO__OO______",
    ],
    # ─── Skeleton Frame 1: Walk left foot ─────────────────────────────
    "enemy_skeleton_f1": [
        "________________",
        "________________",
        "_____OOOO_______",
        "____OWWWWO______",
        "____OWOWWO______",
        "____OWWWWO______",
        "_____OWWO_______",
        "______OO________",
        "____OWWWWO______",
        "___OOWWWWOO_____",
        "__OW_OWWO_WO____",
        "_OW___OO________",
        "______WW________",
        "____OWWWO_______",
        "___OW___WO______",
        "___OO____OO_____",
    ],
    # ─── Skeleton Frame 2: Stride ─────────────────────────────────────
    "enemy_skeleton_f2": [
        "________________",
        "________________",
        "_____OOOO_______",
        "____OWWWWO______",
        "____OWOWWO______",
        "____OWWWWO______",
        "_____OWWO_______",
        "______OO________",
        "____OWWWWO______",
        "___OOWWWWOO_____",
        "____OWWWWO______",
        "____OOWWOO______",
        "______WW________",
        "_____OWWO_______",
        "___OWO__OWO_____",
        "___OO____OO_____",
    ],
    # ─── Skeleton Frame 3: Walk right foot ────────────────────────────
    "enemy_skeleton_f3": [
        "________________",
        "________________",
        "_____OOOO_______",
        "____OWWWWO______",
        "____OWOWWO______",
        "____OWWWWO______",
        "_____OWWO_______",
        "______OO________",
        "____OWWWWO______",
        "___OOWWWWOO_____",
        "__OW_OWWO_WO____",
        "________OO_WO___",
        "______WW________",
        "______OWWWO_____",
        "____OW___WO_____",
        "____OO___OO_____",
    ],
    # ─── Ghost Frame 0: Visible ───────────────────────────────────────
    "enemy_ghost_f0": [
        "________________",
        "________________",
        "____OOOOOO______",
        "___OWWWWWWO_____",
        "___OWWWWWWO_____",
        "___OWOWWOWO_____",
        "___OWWWWWWO_____",
        "___OWWOOWWO_____",
        "___OWWWWWWO_____",
        "___OWWWWWWO_____",
        "___OWWWWWWO_____",
        "___OWWWWWWO_____",
        "___OWO_WOWO_____",
        "____O___OO______",
        "________________",
        "________________",
    ],
    # ─── Ghost Frame 1: Fading ────────────────────────────────────────
    "enemy_ghost_f1": [
        "________________",
        "________________",
        "________________",
        "____OOOOOO______",
        "___OWWWWWWO_____",
        "___OWWWWWWO_____",
        "___OWOWWOWO_____",
        "___OWWWWWWO_____",
        "___OWWOOWWO_____",
        "___OWWWWWWO_____",
        "___OWWWWWWO_____",
        "___OW_WWOWO_____",
        "____O___OO______",
        "________________",
        "________________",
        "________________",
    ],
}

# ═══════════════════════════════════════════════════════════════════════════════
# COLLECTIBLE SPRITES (16×16)
# ═══════════════════════════════════════════════════════════════════════════════

COLLECTIBLE_SPRITES = {
    # ─── Coin Frame 0: Full face ──────────────────────────────────────
    "coin_f0": [
        "________________",
        "________________",
        "________________",
        "_____OOOOOO_____",
        "____OGGGGGGO____",
        "___OGGGGGGGO____",
        "___OGGGOOGGO____",
        "___OGGGOGGGO____",
        "___OGGGGGGO_____",
        "___OGGGOGGGO____",
        "___OGGGOOGGO____",
        "___OGGGGGGGO____",
        "____OGGGGGGO____",
        "_____OOOOOO_____",
        "________________",
        "________________",
    ],
    # ─── Coin Frame 1: Turning ────────────────────────────────────────
    "coin_f1": [
        "________________",
        "________________",
        "________________",
        "______OOOO______",
        "_____OGGGGO_____",
        "_____OGGGO______",
        "_____OGOOO______",
        "_____OGOGGO_____",
        "_____OGGGO______",
        "_____OGOGGO_____",
        "_____OGOOO______",
        "_____OGGGO______",
        "_____OGGGGO_____",
        "______OOOO______",
        "________________",
        "________________",
    ],
    # ─── Coin Frame 2: Edge ───────────────────────────────────────────
    "coin_f2": [
        "________________",
        "________________",
        "________________",
        "_______OO_______",
        "______OGGO______",
        "______OGGO______",
        "______OGGO______",
        "______OGGO______",
        "______OGGO______",
        "______OGGO______",
        "______OGGO______",
        "______OGGO______",
        "______OGGO______",
        "_______OO_______",
        "________________",
        "________________",
    ],
    # ─── Coin Frame 3: Turning back ──────────────────────────────────
    "coin_f3": [
        "________________",
        "________________",
        "________________",
        "______OOOO______",
        "_____OGGGGO_____",
        "______OGGO______",
        "______OOOGO_____",
        "_____OGGOGO_____",
        "______OGGO______",
        "_____OGGOGO_____",
        "______OOOGO_____",
        "______OGGO______",
        "_____OGGGGO_____",
        "______OOOO______",
        "________________",
        "________________",
    ],
    # ─── Gem Frame 0: Normal ─────────────────────────────────────────
    "gem_f0": [
        "________________",
        "________________",
        "________________",
        "______OOOO______",
        "_____OggggO_____",
        "____OggWgggO____",
        "____OgggggggO___",
        "___OgggWggggO___",
        "___OggggggggO___",
        "____OgggggggO___",
        "____OggggggO____",
        "_____OggggO_____",
        "______OOOO______",
        "________________",
        "________________",
        "________________",
    ],
    # ─── Gem Frame 1: Sparkle ─────────────────────────────────────────
    "gem_f1": [
        "________________",
        "________W_______",
        "______OOOO______",
        "_____OggggO_____",
        "____OgWWgggO____",
        "____OggWgggO____",
        "___OgggggggO____",
        "___OggggggggO___",
        "____OgggggggO___",
        "____OggggggO____",
        "_____OggggO_____",
        "______OOOO______",
        "___W____________",
        "________________",
        "________________",
        "________________",
    ],
    # ─── Heart ────────────────────────────────────────────────────────
    "heart": [
        "________________",
        "________________",
        "________________",
        "__OOO____OOO____",
        "_ORRRO__ORRRO___",
        "_ORWRRO_ORRRO___",
        "_ORRRRRORRRO____",
        "__ORRRRRRRO_____",
        "__ORRRRRRRRO____",
        "___ORRRRRRRO____",
        "____ORRRRRRO____",
        "_____ORRRRO_____",
        "______ORRO______",
        "_______OO_______",
        "________________",
        "________________",
    ],
    # ─── Star ─────────────────────────────────────────────────────────
    "star": [
        "________________",
        "________________",
        "_______OO_______",
        "______OGGO______",
        "______OGGO______",
        "___OOGGGGOO_____",
        "___OGGGGGGGOO___",
        "____OGGWWGGO____",
        "____OGGWWGGO____",
        "___OGGGGGGGOO___",
        "___OOGGGGOO_____",
        "______OGGO______",
        "_____OGGGO______",
        "____OGGO_OGO____",
        "____OO____OO____",
        "________________",
    ],
}

# ═══════════════════════════════════════════════════════════════════════════════
# TILE SPRITES (16×16)
# ═══════════════════════════════════════════════════════════════════════════════

TILE_SPRITES = {
    # ─── Terrain ──────────────────────────────────────────────────────
    "grass_top": [
        "__LL_LLLL_LL_LLL",
        "_LLLLLLLLLLLLLL_",
        "OLLLLLLLLLLLLLLO",
        "ODDDDDDDDDDDDDO",
        "ODDDDDDDDDDDDDO",
        "ODDDDDDDDDDDDDO",
        "ODDDDDDDDDDDDDO",
        "ODDDDDDDDDDDDDO",
        "ODDDDDDDDDDDDDO",
        "ODDDDDDDDDDDDDO",
        "ODDDDDDDDDDDDDO",
        "ODDDDDDDDDDDDDO",
        "ODDDDDDDDDDDDDO",
        "ODDDDDDDDDDDDDO",
        "ODDDDDDDDDDDDDO",
        "ODDDDDDDDDDDDDO",
    ],
    "grass_mid": [
        "ODDDDDDDDDDDDDO",
        "ODDDDDDDDDDDDDO",
        "ODDDDDDdDDDDDDO",
        "ODDDDDDDDDDDDDO",
        "ODDDDDDDDDDDDDO",
        "ODDdDDDDDDDDDDO",
        "ODDDDDDDDDDDDDO",
        "ODDDDDDDDDDDDDO",
        "ODDDDDDDDDDDDDO",
        "ODDDDDDDDDdDDDO",
        "ODDDDDDDDDDDDDO",
        "ODDDDDDDDDDDDDO",
        "ODDDDDDDDDDDDDO",
        "ODDdDDDDDDDDDDO",
        "ODDDDDDDDDDDDDO",
        "ODDDDDDDDDDDDDO",
    ],
    "dirt": [
        "ODDDDDDDDDDDDDO",
        "ODDDDdDDDDDDDDO",
        "ODDDDDDDDDDDDDO",
        "ODDDDDDDDDdDDDO",
        "ODDDDDDDDDDDDDO",
        "ODDDDDDDDDDDDDO",
        "ODDDdDDDDDDDDDO",
        "ODDDDDDDDDDDDDO",
        "ODDDDDDDDDDDDDO",
        "ODDDDDDDDDDDdDO",
        "ODDDDDDDDDDDDDO",
        "ODDdDDDDDDDDDDO",
        "ODDDDDDDDDDDDDO",
        "ODDDDDDDDDDDDDO",
        "ODDDDDDdDDDDDDO",
        "ODDDDDDDDDDDDDO",
    ],
    "stone_block": [
        "OOOOOOOOOOOOOOOO",
        "OddddddddddddOO",
        "OddddddddddddOO",
        "OddddddddddddOO",
        "OddddddddddddOO",
        "OddddddddddddOO",
        "OddddddddddddOO",
        "OOOOOOOOOOOOOOOO",
        "OOddddddOddddOO",
        "OOddddddOddddOO",
        "OOddddddOddddOO",
        "OOddddddOddddOO",
        "OOddddddOddddOO",
        "OOddddddOddddOO",
        "OOddddddOddddOO",
        "OOOOOOOOOOOOOOOO",
    ],
    "brick_block": [
        "OOOOOOOOOOOOOOOO",
        "OKKKKKkOKKKKKKk",
        "OKKKKKkOKKKKKKk",
        "OOOOOOOOOOOOOOOO",
        "KKkOKKKKKKkOKKK",
        "KKkOKKKKKKkOKKK",
        "OOOOOOOOOOOOOOOO",
        "OKKKKKkOKKKKKKk",
        "OKKKKKkOKKKKKKk",
        "OOOOOOOOOOOOOOOO",
        "KKkOKKKKKKkOKKK",
        "KKkOKKKKKKkOKKK",
        "OOOOOOOOOOOOOOOO",
        "OKKKKKkOKKKKKKk",
        "OKKKKKkOKKKKKKk",
        "OOOOOOOOOOOOOOOO",
    ],

    # ─── Background ──────────────────────────────────────────────────
    "cloud_left": [
        "________________",
        "________________",
        "________________",
        "________________",
        "________________",
        "________________",
        "______OOOOO_____",
        "____OOWWWWWO____",
        "___OWWWWWWWWO___",
        "__OWWWWWWWWWWO__",
        "__OWWWWWWWWWWOO_",
        "___OOOOOOOOOOO__",
        "________________",
        "________________",
        "________________",
        "________________",
    ],
    "cloud_mid": [
        "________________",
        "________________",
        "________________",
        "________________",
        "________________",
        "____OOOO________",
        "___OWWWWO_______",
        "__OWWWWWWO______",
        "_OWWWWWWWWO_____",
        "OWWWWWWWWWWO____",
        "OWWWWWWWWWWWO___",
        "_OOOOOOOOOOOO___",
        "________________",
        "________________",
        "________________",
        "________________",
    ],
    "cloud_right": [
        "________________",
        "________________",
        "________________",
        "________________",
        "________________",
        "________________",
        "________________",
        "_OOOOO__________",
        "OWWWWWOO________",
        "OWWWWWWWO_______",
        "OWWWWWWWWO______",
        "_OOOOOOOOO______",
        "________________",
        "________________",
        "________________",
        "________________",
    ],
    "bush": [
        "________________",
        "________________",
        "________________",
        "________________",
        "________________",
        "________________",
        "________________",
        "________________",
        "____OOOOOOO_____",
        "___OLLLLLLLLO___",
        "__OLLLWLLLLLLLO_",
        "__OLLLLLLLLLLLLO",
        "_OLLLLWLLLLLLLLO",
        "_OLLLLLLLLLLLLO_",
        "__OOOOOOOOOOO___",
        "________________",
    ],
    "tree": [
        "____OOOOO_______",
        "___OLLLLLLO_____",
        "__OLLLWLLLLLO___",
        "__OLLLLLLLLLO___",
        "_OLLLLLLLLLLLLO_",
        "_OLLLWLLLLLLLO__",
        "_OLLLLLLLLLLLLO_",
        "__OLLLLLLLLLO___",
        "___OOLLLLOO_____",
        "______OTO_______",
        "______OTO_______",
        "______OTO_______",
        "______OTO_______",
        "______OTO_______",
        "_____OOTTO______",
        "_____OOOOO______",
    ],

    # ─── Interactive ──────────────────────────────────────────────────
    "question_block_f0": [
        "OOOOOOOOOOOOOOOO",
        "OGGGGGGGGGGGGGO",
        "OGGGGGGGGGGGGGOO",
        "OGGGGOOOOGGGGGk",
        "OGGGOGGGGOGGGGk",
        "OGGGGGGGGOGGGGk",
        "OGGGGGGGOGGGGGk",
        "OGGGGGGOGGGGGGk",
        "OGGGGGOGGGGGGGk",
        "OGGGGGGGGGGGGGk",
        "OGGGGGOGGGGGGGk",
        "OGGGGGGGGGGGGGk",
        "OGGGGGGGGGGGGGk",
        "OkkkkkkkkkkkkkOO",
        "OOOOOOOOOOOOOOOO",
        "________________",
    ],
    "question_block_f1": [
        "OOOOOOOOOOOOOOOO",
        "OGGGGGGGGGGGGGOO",
        "OGGGGGGGGGGGGGk",
        "OGGGGGGGGGGGGGk",
        "OGGGGOOOOGGGGGk",
        "OGGGOGGGGOGGGGk",
        "OGGGGGGGGOGGGGk",
        "OGGGGGGGOGGGGGk",
        "OGGGGGGOGGGGGGk",
        "OGGGGGGGGGGGGGk",
        "OGGGGGOGGGGGGGk",
        "OGGGGGGGGGGGGGk",
        "OGGGGGGGGGGGGGk",
        "OkkkkkkkkkkkkkOO",
        "OOOOOOOOOOOOOOOO",
        "________________",
    ],
    "breakable_block": [
        "OOOOOOOOOOOOOOOO",
        "OKKKKOKKKOKKKKk",
        "OKKKKOKKKOKKKKk",
        "OKKKKOKKKOKKKKk",
        "OOOOOOOOOOOOOOOO",
        "OKKOKKKKOKKKKOk",
        "OKKOKKKKOKKKKOk",
        "OKKOKKKKOKKKKOk",
        "OOOOOOOOOOOOOOOO",
        "OKKKKOKKKOKKKKk",
        "OKKKKOKKKOKKKKk",
        "OKKKKOKKKOKKKKk",
        "OOOOOOOOOOOOOOOO",
        "OKKOKKKKOKKKKOk",
        "OKKOKKKKOKKKKOk",
        "OOOOOOOOOOOOOOOO",
    ],
    "spike_trap": [
        "________________",
        "________________",
        "________________",
        "________________",
        "________________",
        "________________",
        "________________",
        "________________",
        "________________",
        "______O___O_____",
        "_O___OdO_OdO__O_",
        "OdO_OdddOdddOOdO",
        "OddOOdddOdddOddO",
        "OdddOdddOdddOddO",
        "OddddddddddddddO",
        "OOOOOOOOOOOOOOOO",
    ],

    # ─── Decorations ─────────────────────────────────────────────────
    "flower": [
        "________________",
        "________________",
        "________________",
        "________________",
        "________________",
        "________________",
        "________________",
        "________________",
        "________________",
        "________________",
        "____Or_rO_______",
        "___OrGrGrO______",
        "____OrrrO_______",
        "_____OLO________",
        "____OLLO________",
        "____OLO_________",
    ],
    "mushroom": [
        "________________",
        "________________",
        "________________",
        "________________",
        "________________",
        "________________",
        "________________",
        "____OOOOOOO_____",
        "___OrrrWrrrrO___",
        "__OrrrrWrrrrO___",
        "__OrrWWWWrrrO___",
        "___OOOOOOOOO____",
        "_____OWWWO______",
        "_____OWWWO______",
        "____OOWWWOO_____",
        "____OOOOOOO_____",
    ],
    "sign_post": [
        "________________",
        "________________",
        "________________",
        "__OOOOOOOOOO____",
        "__OddddddddO___",
        "__OTTTTTTTTTO___",
        "__OddddddddO___",
        "__OOOOOOOOOO____",
        "______OTO_______",
        "______OTO_______",
        "______OTO_______",
        "______OTO_______",
        "______OTO_______",
        "______OTO_______",
        "_____OOTTO______",
        "_____OOOOO______",
    ],
}


def pixel_data_to_svg(
    pixel_rows: list[str],
    pixel_size: int = 8,
    name: str = "sprite",
) -> str:
    """Convert pixel data to SVG. Each char maps to PALETTE color."""
    grid_w = len(pixel_rows[0])
    grid_h = len(pixel_rows)
    width = grid_w * pixel_size
    height = grid_h * pixel_size
    parts = [
        f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 {width} {height}" '
        f'width="{width}" height="{height}" shape-rendering="crispEdges">',
        f"  <title>{name}</title>",
    ]
    for y, row in enumerate(pixel_rows):
        for x, c in enumerate(row):
            color = PALETTE.get(c)
            if color is None:
                continue
            parts.append(
                f'  <rect x="{x * pixel_size}" y="{y * pixel_size}" '
                f'width="{pixel_size}" height="{pixel_size}" fill="{color}"/>'
            )
    parts.append("</svg>")
    return "\n".join(parts)


def create_spritesheet_svg(
    sprites: dict[str, list[str]],
    columns: int = 8,
    pixel_size: int = 8,
    title: str = "Sprite Sheet",
) -> str:
    """Combine sprites into a single sprite sheet SVG."""
    names = list(sprites.keys())
    if not names:
        return ""
    grid_w = len(sprites[names[0]][0])
    grid_h = len(sprites[names[0]])
    tile_w = grid_w * pixel_size
    tile_h = grid_h * pixel_size
    rows = (len(names) + columns - 1) // columns
    sheet_w = columns * tile_w
    sheet_h = rows * tile_h

    parts = [
        f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 {sheet_w} {sheet_h}" '
        f'width="{sheet_w}" height="{sheet_h}" shape-rendering="crispEdges">',
        f"<title>{title}</title>",
    ]

    for idx, name in enumerate(names):
        col = idx % columns
        row = idx // columns
        ox = col * tile_w
        oy = row * tile_h
        parts.append(f'  <g id="{name}" transform="translate({ox},{oy})">')
        for y, prow in enumerate(sprites[name]):
            for x, c in enumerate(prow):
                color = PALETTE.get(c)
                if color is None:
                    continue
                parts.append(
                    f'    <rect x="{x * pixel_size}" y="{y * pixel_size}" '
                    f'width="{pixel_size}" height="{pixel_size}" fill="{color}"/>'
                )
        parts.append("  </g>")

    parts.append("</svg>")
    return "\n".join(parts)


def main() -> None:
    """Generate all platformer sprite SVGs."""
    out = os.path.dirname(os.path.abspath(__file__))

    all_sprites = {}
    all_sprites.update(PLAYER_SPRITES)
    all_sprites.update(ENEMY_SPRITES)
    all_sprites.update(COLLECTIBLE_SPRITES)
    all_sprites.update(TILE_SPRITES)

    print("Retro Platformer Kit — SVG Generator")
    print("=" * 40)

    # Individual sprites
    for name, data in all_sprites.items():
        svg = pixel_data_to_svg(data, name=name)
        path = os.path.join(out, f"{name}.svg")
        with open(path, "w") as f:
            f.write(svg)
        print(f"  {name}.svg")

    # Combined sprite sheets by category
    print()

    player_sheet = create_spritesheet_svg(
        PLAYER_SPRITES, columns=4, title="Player Sprites"
    )
    path = os.path.join(out, "player_sheet.svg")
    with open(path, "w") as f:
        f.write(player_sheet)
    print(f"  player_sheet.svg ({len(PLAYER_SPRITES)} sprites)")

    enemy_sheet = create_spritesheet_svg(
        ENEMY_SPRITES, columns=4, title="Enemy Sprites"
    )
    path = os.path.join(out, "enemy_sheet.svg")
    with open(path, "w") as f:
        f.write(enemy_sheet)
    print(f"  enemy_sheet.svg ({len(ENEMY_SPRITES)} sprites)")

    collectible_sheet = create_spritesheet_svg(
        COLLECTIBLE_SPRITES, columns=4, title="Collectible Sprites"
    )
    path = os.path.join(out, "collectible_sheet.svg")
    with open(path, "w") as f:
        f.write(collectible_sheet)
    print(f"  collectible_sheet.svg ({len(COLLECTIBLE_SPRITES)} sprites)")

    tile_sheet = create_spritesheet_svg(
        TILE_SPRITES, columns=8, title="Tileset"
    )
    path = os.path.join(out, "tileset.svg")
    with open(path, "w") as f:
        f.write(tile_sheet)
    print(f"  tileset.svg ({len(TILE_SPRITES)} tiles)")

    # Master sheet
    master = {}
    master.update(ENEMY_SPRITES)
    master.update(COLLECTIBLE_SPRITES)
    master.update(TILE_SPRITES)
    master_sheet = create_spritesheet_svg(
        master, columns=8, title="All 16x16 Sprites"
    )
    path = os.path.join(out, "all_16x16.svg")
    with open(path, "w") as f:
        f.write(master_sheet)
    print(f"  all_16x16.svg (combined 16x16 sheet)")

    print(f"\nDone! Generated {len(all_sprites)} individual SVGs + 5 sheets.")


if __name__ == "__main__":
    main()
