# Pixel Forge Starter Bundle — Contents

## Included Products

1. **explosion-vfx-pack/** — Explosion VFX Pack ($3)
   - 6 explosion types × 8 frames = 46 animated frames
   - Fire, plasma, smoke, spark, energy ring, pixel shatter
   - SVG + Python generator

2. **pixel-font-pack/** — Pixel Font Pack ($3)
   - 3 complete pixel fonts (Regular, Bold, Handwritten)
   - Full A-Z, a-z, 0-9, common punctuation
   - SVG glyphs + Python generator

3. **space-shooter-assets/** — Space Shooter Assets ($3)
   - 3 player ships, 4 enemy types, asteroids
   - Projectiles, power-ups, explosions, star backgrounds
   - SVG + Python generator

## Total Value: $9 (vs $12 individual = 25% savings)
