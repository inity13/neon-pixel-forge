# 🎮 Pixel Forge Starter Bundle

**Get started with game development! 3 essential asset packs at a massive discount.**

> Save 25% vs buying individually ($9 vs $12)

## What's Included

| Product | Individual Price | Description |
|---------|-----------------|-------------|
| [Explosion VFX Pack](../explosion-vfx-pack/) | $3 | 6 animated explosion types, 46 frames |
| [Pixel Font Pack](../pixel-font-pack/) | $3 | 3 pixel fonts (Regular, Bold, Handwritten) |
| [Space Shooter Assets](../space-shooter-assets/) | $3 | Ships, enemies, projectiles, backgrounds |
| **Bundle Price** | **$9** | **Save $3 (25%)** |

## Perfect For

- 🚀 First-time game developers
- 🎮 Game jam participants
- 💫 Quick prototype builders
- 🏫 Students learning game dev

## How It Works

1. Purchase the bundle via Neon Bazaar
2. Download the ZIP containing all 3 product packs
3. Each pack is in its own folder with README, source files, demos, and previews
4. Import into your engine of choice (Godot, Unity, Web — see USAGE.md in each pack)

## License

MIT License — use in personal and commercial projects. See LICENSE file.
