#!/usr/bin/env python3
"""
Dungeon Tileset Generator — Pixel Forge
Generates 16×16 dungeon tiles as SVG pixel art.

Each tile is defined as a 16×16 character grid where each character
maps to a color in the dungeon palette. Outputs individual SVGs and
a combined tileset sheet.

Usage:
    python3 generate_tiles.py
"""

import json
import os
from typing import Optional

# ─── Dungeon Palette ──────────────────────────────────────────────────────────
PALETTE = {
    "_": None,           # transparent
    "V": "#0a0a12",      # void
    "0": "#2a2a3a",      # stone dark
    "1": "#4a4a5a",      # stone mid
    "2": "#6a6a7a",      # stone light
    "B": "#5a4030",      # brick
    "b": "#7a6050",      # brick light
    "W": "#6b4226",      # wood
    "w": "#8b6246",      # wood light
    "M": "#808890",      # metal
    "G": "#c8a848",      # gold
    "F": "#ff8830",      # torch fire
    "f": "#ffcc44",      # torch glow
    "A": "#3060a0",      # water
    "L": "#cc3300",      # lava
    "m": "#3a6a2a",      # moss
    "R": "#8a1818",      # blood
    "O": "#1a1a2e",      # outline
}

# ─── Tile Definitions (16×16 each) ───────────────────────────────────────────
# Each tile is a list of 16 strings, each 16 characters long.

TILES = {
    # === FLOORS ===
    "floor_stone": [
        "1111111111111111",
        "1112111111111111",
        "1111111111211111",
        "1111111111111111",
        "1111111111111111",
        "1111211111111111",
        "1111111111111111",
        "1111111111111211",
        "1111111111111111",
        "1111111121111111",
        "1111111111111111",
        "1111111111111111",
        "1112111111111111",
        "1111111111111111",
        "1111111111121111",
        "1111111111111111",
    ],
    "floor_stone_cracked": [
        "1111111111111111",
        "1112111101111111",
        "1111111101111111",
        "1111110011111111",
        "1111100111111111",
        "1111011111111111",
        "1111011111111111",
        "1111101111111111",
        "1111110111111111",
        "1111110111111111",
        "1111111011111111",
        "1111111101111111",
        "1111111101111111",
        "1111111011111111",
        "1111111111111111",
        "1111111111111111",
    ],
    "floor_stone_mossy": [
        "111m1111mm111111",
        "11mm111mmm111111",
        "1mmm11mm11111111",
        "1mm1111111111111",
        "1111111111111111",
        "111111111111mm11",
        "11111111111mmm11",
        "1111111111mmm111",
        "111111111mm11111",
        "1111111111111111",
        "1111111111111111",
        "1mm1111111111111",
        "mmm1111111111mm1",
        "mm11111111111mmm",
        "1111111111111mm1",
        "1111111111111111",
    ],
    "floor_dirt": [
        "0000000000000000",
        "0001000000000100",
        "0000000100000000",
        "0000000000000000",
        "0000001000000000",
        "0100000000010000",
        "0000000000000000",
        "0000010000000000",
        "0000000000010000",
        "0000000000000000",
        "0010000000000000",
        "0000000010000000",
        "0000000000000010",
        "0000000000000000",
        "0000100000000000",
        "0000000000000000",
    ],
    "floor_brick": [
        "BBBBBBBbOBBBBBBb",
        "BBBBBBBbOBBBBBBb",
        "OOOOOOOOOOOOOOOO",
        "BBbOBBBBBBBbOBBB",
        "BBbOBBBBBBBbOBBB",
        "OOOOOOOOOOOOOOOO",
        "BBBBBBBbOBBBBBBb",
        "BBBBBBBbOBBBBBBb",
        "OOOOOOOOOOOOOOOO",
        "BBbOBBBBBBBbOBBB",
        "BBbOBBBBBBBbOBBB",
        "OOOOOOOOOOOOOOOO",
        "BBBBBBBbOBBBBBBb",
        "BBBBBBBbOBBBBBBb",
        "OOOOOOOOOOOOOOOO",
        "BBbOBBBBBBBbOBBB",
    ],
    "floor_blood": [
        "1111111111111111",
        "1111R11111111111",
        "111RRR1111111111",
        "11RRRRR111111111",
        "111RRRR111111111",
        "1111RRR111111111",
        "11111RR111111111",
        "1111111111111111",
        "11111111111R1111",
        "1111111111RR1111",
        "111111111RRR1111",
        "1111111111RR1111",
        "11111111111R1111",
        "1111111111111111",
        "1111111111111111",
        "1111111111111111",
    ],

    # === WALLS ===
    "wall_top": [
        "OOOOOOOOOOOOOOOO",
        "O001001001001001",
        "O012012012012012",
        "O012012012012012",
        "O012012012012012",
        "O001001001001001",
        "OOOOOOOOOOOOOOOO",
        "0000000000000000",
        "0000000000000000",
        "0000000000000000",
        "0000000000000000",
        "0000000000000000",
        "0000000000000000",
        "0000000000000000",
        "0000000000000000",
        "0000000000000000",
    ],
    "wall_bottom": [
        "0000000000000000",
        "0000000000000000",
        "0000000000000000",
        "0000000000000000",
        "0000000000000000",
        "0000000000000000",
        "0000000000000000",
        "0000000000000000",
        "0000000000000000",
        "OOOOOOOOOOOOOOOO",
        "O001001001001001",
        "O012012012012012",
        "O012012012012012",
        "O012012012012012",
        "O001001001001001",
        "OOOOOOOOOOOOOOOO",
    ],
    "wall_left": [
        "OO00000000000000",
        "O200000000000000",
        "O100000000000000",
        "O100000000000000",
        "O100000000000000",
        "O200000000000000",
        "OO00000000000000",
        "O200000000000000",
        "O100000000000000",
        "O100000000000000",
        "O100000000000000",
        "O200000000000000",
        "OO00000000000000",
        "O200000000000000",
        "O100000000000000",
        "O100000000000000",
    ],
    "wall_right": [
        "00000000000000OO",
        "000000000000002O",
        "000000000000001O",
        "000000000000001O",
        "000000000000001O",
        "000000000000002O",
        "00000000000000OO",
        "000000000000002O",
        "000000000000001O",
        "000000000000001O",
        "000000000000001O",
        "000000000000002O",
        "00000000000000OO",
        "000000000000002O",
        "000000000000001O",
        "000000000000001O",
    ],
    "wall_corner_tl": [
        "OOOOOOOOOOOOOOOO",
        "OO2OO12012012012",
        "O201012012012012",
        "O101012012012012",
        "O101001001001001",
        "O201OOOOOOOOOOOO",
        "OO000000000000OO",
        "O2000000000000OO",
        "O1000000000000OO",
        "O1000000000000OO",
        "O1000000000000OO",
        "O2000000000000OO",
        "OO000000000000OO",
        "O2000000000000OO",
        "O1000000000000OO",
        "O1000000000000OO",
    ],
    "wall_corner_tr": [
        "OOOOOOOOOOOOOOOO",
        "012012012012OO2O",
        "012012012012O102",
        "012012012012O101",
        "001001001001O101",
        "OOOOOOOOOOOOO201",
        "OO000000000000OO",
        "OO000000000000O2",
        "OO000000000000O1",
        "OO000000000000O1",
        "OO000000000000O1",
        "OO000000000000O2",
        "OO000000000000OO",
        "OO000000000000O2",
        "OO000000000000O1",
        "OO000000000000O1",
    ],

    # === DOORS ===
    "door_closed": [
        "OOOOOOOOOOOOOOOO",
        "OWWWWwWWWwWWWWWO",
        "OWWWWWWWWWWWWWWO",
        "OWWWWWWWWWWWWWWO",
        "OWWWWWWWWWWWWWWO",
        "OWWWWwWWWwWWWWWO",
        "OWWWWWWWWWWWWWWO",
        "OWWWWWWGWWWWWWWO",
        "OWWWWWWWWWWWWWWO",
        "OWWWWwWWWwWWWWWO",
        "OWWWWWWWWWWWWWWO",
        "OWWWWWWWWWWWWWWO",
        "OWWWWWWWWWWWWWWO",
        "OWWWWwWWWwWWWWWO",
        "OWWWWWWWWWWWWWWO",
        "OOOOOOOOOOOOOOOO",
    ],
    "door_open": [
        "OOOOOOOOOOOOOOOO",
        "OW11111111111WwO",
        "OW11111111111WwO",
        "OW11111111111WwO",
        "OW11111111111WwO",
        "OW11111111111WwO",
        "OW11111111111WwO",
        "OW11111111111WwO",
        "OW11111111111WwO",
        "OW11111111111WwO",
        "OW11111111111WwO",
        "OW11111111111WwO",
        "OW11111111111WwO",
        "OW11111111111WwO",
        "OW11111111111WwO",
        "OOOOOOOOOOOOOOOO",
    ],
    "door_iron_gate": [
        "MMMMMMMMMMMMMMOM",
        "M__M__M__M__M__M",
        "M__M__M__M__M__M",
        "M__M__M__M__M__M",
        "M__M__M__M__M__M",
        "MMMMMMMMMMMMMMOM",
        "M__M__M__M__M__M",
        "M__M__M__M__M__M",
        "M__M__M__M__M__M",
        "M__M__M__M__M__M",
        "MMMMMMMMMMMMMMOM",
        "M__M__M__M__M__M",
        "M__M__M__M__M__M",
        "M__M__M__M__M__M",
        "M__M__M__M__M__M",
        "MMMMMMMMMMMMMMOM",
    ],

    # === TRAPS ===
    "trap_spikes_up": [
        "1111111111111111",
        "1111111111111111",
        "111O1111O111O111",
        "11O2O11O2O1O2O11",
        "1O222OO222OO222O",
        "O2M2MOM2M2MO2M2O",
        "O2M2MOM2M2MO2M2O",
        "O1M1MOO1M1MOO1M1",
        "O0M0M0O0M0M0O0M0",
        "1OMO1O1OMO1O1OMO",
        "11O111O1O1111O11",
        "1111111111111111",
        "1111111111111111",
        "1111111111111111",
        "1111111111111111",
        "1111111111111111",
    ],
    "trap_spikes_down": [
        "1111111111111111",
        "1111111111111111",
        "1111111111111111",
        "1111111111111111",
        "1111111111111111",
        "11O111O1O1111O11",
        "1OMO1O1OMO1O1OMO",
        "O0M0M0O0M0M0O0M0",
        "O1M1MOO1M1MOO1M1",
        "O2M2MOM2M2MO2M2O",
        "O2M2MOM2M2MO2M2O",
        "1O222OO222OO222O",
        "11O2O11O2O1O2O11",
        "111O1111O111O111",
        "1111111111111111",
        "1111111111111111",
    ],
    "trap_lava_pit": [
        "0000000000000000",
        "0OOOOOOOOOOOOOO0",
        "0OLLLLLLLLLLLLO0",
        "0OLLLLLLLLLLLRO0",
        "0OLLLLLLLLLLLLO0",
        "0OLLLLLRLLLLLRO0",
        "0OLLLLLLLLLLLLO0",
        "0OLLRLLLLLRLLRO0",
        "0OLLLLLLLLLLLLO0",
        "0OLLLLLLLRLLLRO0",
        "0OLLLLLLLLLLLLO0",
        "0OLLLLLLLLLLLRO0",
        "0OLLLLRLLLLLLLO0",
        "0OOOOOOOOOOOOOO0",
        "0000000000000000",
        "0000000000000000",
    ],

    # === DECORATIONS ===
    "deco_chest_closed": [
        "________________",
        "________________",
        "________________",
        "________________",
        "________________",
        "___OOOOOOOOOO___",
        "__OGGGGGGGGGO___",
        "__OWWWGWGWWWO___",
        "__OWWWWGWWWWO___",
        "__OWWWWWWWWWO___",
        "__OWWWWWWWWWO___",
        "__OWWWWWWWWWO___",
        "__OOOOOOOOOOOO__",
        "________________",
        "________________",
        "________________",
    ],
    "deco_chest_open": [
        "________________",
        "________________",
        "__OOOOOOOOOO____",
        "__OWWWWWWWWWO___",
        "__OWWWWWWWWWWO__",
        "___OWWWWWWWWWO__",
        "___OGGGGGGGGGO__",
        "__OWGGGGGGGWWO__",
        "__OWWWWWWWWWWO__",
        "__OWWWWGWWWWWO__",
        "__OWWWWWWWWWWO__",
        "__OWWWWWWWWWWO__",
        "__OOOOOOOOOOOO__",
        "________________",
        "________________",
        "________________",
    ],
    "deco_barrel": [
        "________________",
        "________________",
        "________________",
        "____OOOOOO______",
        "___OWWWWWWO_____",
        "___OwWwWwWwO____",
        "___OWWWWWWWO____",
        "___OWWWWWWWO____",
        "___OwWwWwWwO____",
        "___OWWWWWWWO____",
        "___OWWWWWWWO____",
        "___OwWwWwWwO____",
        "___OWWWWWWWO____",
        "____OOOOOO______",
        "________________",
        "________________",
    ],
    "deco_skull": [
        "________________",
        "________________",
        "________________",
        "________________",
        "________________",
        "________________",
        "____OOOOOO______",
        "___O222222O_____",
        "___O2O22O2O_____",
        "___O222222O_____",
        "____O2OO2O______",
        "____OOOOOO______",
        "_____O22O_______",
        "_____OOOO_______",
        "________________",
        "________________",
    ],
    "deco_web": [
        "O___________O__O",
        "_O_________O__O_",
        "__O_______O__O__",
        "___O_____O_O____",
        "____O___OO______",
        "_____OOO________",
        "______O_________",
        "_____OOO________",
        "____O___O_______",
        "___O_____O______",
        "__O_______O_____",
        "_O_________O____",
        "O___________O___",
        "________________",
        "________________",
        "________________",
    ],

    # === LIGHT SOURCES ===
    "torch_wall_f1": [
        "________________",
        "________________",
        "______fF________",
        "_____fFFf_______",
        "______FF________",
        "______WW________",
        "______WW________",
        "______WW________",
        "______WW________",
        "______WW________",
        "______WW________",
        "________________",
        "________________",
        "________________",
        "________________",
        "________________",
    ],
    "torch_wall_f2": [
        "________________",
        "________________",
        "_______Ff_______",
        "______FFFf______",
        "_______FF_______",
        "______WW________",
        "______WW________",
        "______WW________",
        "______WW________",
        "______WW________",
        "______WW________",
        "________________",
        "________________",
        "________________",
        "________________",
        "________________",
    ],
    "torch_wall_f3": [
        "________________",
        "________________",
        "_____Ff_________",
        "____fFFF________",
        "______FF________",
        "______WW________",
        "______WW________",
        "______WW________",
        "______WW________",
        "______WW________",
        "______WW________",
        "________________",
        "________________",
        "________________",
        "________________",
        "________________",
    ],
    "brazier": [
        "________________",
        "______fFf_______",
        "_____fFFFf______",
        "______FFF_______",
        "______FFF_______",
        "____OMMMMO______",
        "____OMMMMO______",
        "____OMMMMO______",
        "_____OMMO_______",
        "_____OMMO_______",
        "____OMMMO_______",
        "____OMMMMO______",
        "___OMMMMMMO_____",
        "___OOOOOOOO_____",
        "________________",
        "________________",
    ],

    # === WATER ===
    "water_still": [
        "AAAAAAAAAAAAAAAA",
        "AAAAAAAAAAAAAAAA",
        "AAAAAAAAAAAAAAAA",
        "AAAA3AAAAAAAAAAA",
        "AAAAAAAAAAAAAAAA",
        "AAAAAAAAAA3AAAAA",
        "AAAAAAAAAAAAAAAA",
        "AAAAAAAAAAAAAAAA",
        "AA3AAAAAAAAAAAAA",
        "AAAAAAAAAAAAAAAA",
        "AAAAAAAAAAAAAAAA",
        "AAAAAAAA3AAAAAAA",
        "AAAAAAAAAAAAAAAA",
        "AAAAAAAAAAAAAAAA",
        "AAAAAAAAAAAAAAAA",
        "AAAA3AAAAAAAAAAA",
    ],
    "water_edge_top": [
        "1111111111111111",
        "1111111111111111",
        "OO1OO11OO1OO11O",
        "AAAOAAAOAAAOAAAO",
        "AAAAAAAAAAAAAAAA",
        "AAAAAAAAAAAAAAAA",
        "AAAAAAAAAAAAAAAA",
        "AAAAAAAAAAAAAAAA",
        "AAAAAAAAAAAAAAAA",
        "AAAAAAAAAAAAAAAA",
        "AAAAAAAAAAAAAAAA",
        "AAAAAAAAAAAAAAAA",
        "AAAAAAAAAAAAAAAA",
        "AAAAAAAAAAAAAAAA",
        "AAAAAAAAAAAAAAAA",
        "AAAAAAAAAAAAAAAA",
    ],

    # === STAIRS ===
    "stairs_down": [
        "OOOOOOOOOOOOOOOO",
        "OVVVVVVVVVVVVVVO",
        "OVVVVVVVVVVVVVVO",
        "OVVOOOOOOOOOVVVO",
        "OVVO00000000OVVO",
        "OVVO00000000OVVO",
        "OVVO00OOOO00OVVO",
        "OVVO00OVVO00OVVO",
        "OVVO00OVVO00OVVO",
        "OVVO00OVVO00OVVO",
        "OVVO00OOOO00OVVO",
        "OVVO00000000OVVO",
        "OVVO00000000OVVO",
        "OVVOOOOOOOOOVVVO",
        "OVVVVVVVVVVVVVVO",
        "OOOOOOOOOOOOOOOO",
    ],

    # === SPECIAL ===
    "special_save_shrine": [
        "________________",
        "________________",
        "______GG________",
        "_____GGGG_______",
        "______GG________",
        "______GG________",
        "____GGGGGG______",
        "___G111111G_____",
        "___G111111G_____",
        "___G111111G_____",
        "___G111111G_____",
        "___GGGGGGGG_____",
        "___G111111G_____",
        "___GGGGGGGG_____",
        "________________",
        "________________",
    ],
}


def pixel_data_to_svg(
    pixel_rows: list[str],
    pixel_size: int = 8,
    name: str = "tile",
) -> str:
    """Convert pixel data to SVG. Each char maps to PALETTE color."""
    width = len(pixel_rows[0]) * pixel_size
    height = len(pixel_rows) * pixel_size
    parts = [
        f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 {width} {height}" '
        f'width="{width}" height="{height}" shape-rendering="crispEdges">',
        f"  <title>{name}</title>",
    ]
    for y, row in enumerate(pixel_rows):
        for x, c in enumerate(row):
            color = PALETTE.get(c)
            if color is None:
                continue
            parts.append(
                f'  <rect x="{x * pixel_size}" y="{y * pixel_size}" '
                f'width="{pixel_size}" height="{pixel_size}" fill="{color}"/>'
            )
    parts.append("</svg>")
    return "\n".join(parts)


def create_tileset_svg(columns: int = 10, pixel_size: int = 8) -> str:
    """Combine all tiles into a single tileset SVG sheet."""
    tile_names = list(TILES.keys())
    tile_w = 16 * pixel_size
    tile_h = 16 * pixel_size
    rows = (len(tile_names) + columns - 1) // columns
    sheet_w = columns * tile_w
    sheet_h = rows * tile_h

    parts = [
        f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 {sheet_w} {sheet_h}" '
        f'width="{sheet_w}" height="{sheet_h}" shape-rendering="crispEdges">',
        "<title>Dungeon Tileset — Pixel Forge</title>",
    ]

    for idx, name in enumerate(tile_names):
        col = idx % columns
        row = idx // columns
        ox = col * tile_w
        oy = row * tile_h
        parts.append(f'  <g id="{name}" transform="translate({ox},{oy})">')
        for y, prow in enumerate(TILES[name]):
            for x, c in enumerate(prow):
                color = PALETTE.get(c)
                if color is None:
                    continue
                parts.append(
                    f'    <rect x="{x * pixel_size}" y="{y * pixel_size}" '
                    f'width="{pixel_size}" height="{pixel_size}" fill="{color}"/>'
                )
        parts.append("  </g>")

    parts.append("</svg>")
    return "\n".join(parts)


def main() -> None:
    """Generate all dungeon tile SVGs."""
    out = os.path.dirname(os.path.abspath(__file__))

    # Individual tiles
    for name, data in TILES.items():
        svg = pixel_data_to_svg(data, name=name)
        path = os.path.join(out, f"{name}.svg")
        with open(path, "w") as f:
            f.write(svg)
        print(f"  {name}.svg")

    # Combined sheet
    svg = create_tileset_svg()
    path = os.path.join(out, "tileset.svg")
    with open(path, "w") as f:
        f.write(svg)
    print(f"\n  tileset.svg (combined: {len(TILES)} tiles)")


if __name__ == "__main__":
    main()
