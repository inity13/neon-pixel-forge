# 🏰 Dungeon Tileset

**Complete 16×16 dungeon tileset with 200+ unique tiles for top-down or side-scrolling dungeon crawlers.**

```
  ╔════╦════╦════╦════╦════╦════╦════╗
  ║░░░░║████║▓▓▓▓║╬╬╬╬║┌──┐║⌂⌂⌂⌂║≈≈≈≈║
  ║FLOOR║WALL║DOOR║TRAP║DECO║LIGHT║WATER║
  ╚════╩════╩════╩════╩════╩════╩════╝
          Dungeon Tileset Categories
```

## What's Included

| Category       | Tiles | Description |
|----------------|-------|-------------|
| Floors         | 24    | Stone, dirt, brick, cracked, mossy, blood-stained |
| Walls          | 40    | Top, bottom, left, right, corners (inner/outer), pillars |
| Doors          | 16    | Open, closed, locked, iron gate, secret passage |
| Traps          | 20    | Spikes, pit, lava, pressure plate, arrow trap |
| Decorations    | 48    | Chests, barrels, skulls, chains, webs, bones, crates |
| Light Sources  | 16    | Torches (animated), braziers, crystals, lanterns |
| Water/Lava     | 20    | Still, flowing, edge transitions (animated) |
| Stairs/Ladders | 12    | Up, down, spiral, rope ladder |
| Special        | 8     | Spawn point, exit, save shrine, boss arena markers |
| **Total**      | **204** | |

## File Structure

```
dungeon-tileset/
├── README.md              ← You are here
├── USAGE.md               ← Integration guides (Godot, Unity, Tiled, Web)
├── palette.json           ← Color palette (16 colors, dungeon theme)
├── src/
│   ├── tileset.svg        ← Complete tileset in SVG format
│   ├── tileset_data.json  ← Tile definitions, collision flags, auto-tile rules
│   ├── tilemap_sample.json ← Sample map in Tiled-compatible format
│   ├── generate_tiles.py  ← Python SVG generator (stdlib only)
│   └── generate_ppm.py    ← PPM image generator (stdlib only)
├── preview/
│   └── index.html         ← Visual tile catalog in browser
├── demo/
│   └── index.html         ← Interactive dungeon map renderer
└── examples/
    ├── auto_tiling.md     ← How to set up auto-tile rules
    └── tiled_import.md    ← Step-by-step Tiled editor import
```

## Quick Start

1. Open `preview/index.html` to see the full tile catalog
2. Open `demo/index.html` for an interactive dungeon walkthrough
3. Import `src/tileset_data.json` into your game engine

## Color Palette

| Color | Hex | Usage |
|-------|-----|-------|
| Void | `#0a0a12` | Unexplored/empty space |
| Stone Dark | `#2a2a3a` | Deep stone, shadows |
| Stone Mid | `#4a4a5a` | Primary stone surface |
| Stone Light | `#6a6a7a` | Stone highlights |
| Brick | `#5a4030` | Brick walls |
| Brick Light | `#7a6050` | Brick highlights |
| Wood | `#6b4226` | Doors, barrels, crates |
| Wood Light | `#8b6246` | Wood highlights |
| Metal | `#808890` | Iron doors, chains |
| Gold | `#c8a848` | Treasure, trim |
| Torch Fire | `#ff8830` | Torch flames |
| Torch Glow | `#ffcc44` | Light glow |
| Water | `#3060a0` | Water tiles |
| Lava | `#cc3300` | Lava tiles |
| Moss | `#3a6a2a` | Mossy surfaces |
| Blood | `#8a1818` | Blood stains |

## Tile Properties

Each tile in `tileset_data.json` includes:
- `id`: Unique tile ID
- `name`: Human-readable name
- `category`: Floor, wall, door, trap, deco, light, water, stairs, special
- `collision`: Boolean — does this tile block movement?
- `animated`: Boolean — does this tile have animation frames?
- `frames`: Number of animation frames (if animated)
- `frame_duration_ms`: Animation speed (if animated)
- `auto_tile_group`: Group name for auto-tiling (e.g., "stone_wall")
- `variants`: Number of visual variants

## License

MIT License — use in personal and commercial projects. See LICENSE file.
