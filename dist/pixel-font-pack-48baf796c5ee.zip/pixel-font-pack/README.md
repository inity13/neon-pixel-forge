# Pixel Font Pack

**3 pixel fonts on an 8x8 grid — Regular, Bold, and Handwritten — with full A-Z, a-z, 0-9 coverage.**

```
  ╔══════════════════════════════════════════════════════╗
  ║  ████  ██ ██  ██ ████  ██                            ║
  ║  ██ ██ ██  ████  ██    ██                            ║
  ║  ████  ██  ████  ████  ████                          ║
  ║                                                      ║
  ║  ██████ █████ ██   █ ██████                          ║
  ║  ██     ██  █ ███  █   ██                            ║
  ║  ██     █████ ██ ███   ██                            ║
  ╚══════════════════════════════════════════════════════╝
            Pixel Font Pack — 3 Fonts
```

## What's Included

| Font         | Style             | Glyphs | Color   | Description |
|--------------|-------------------|--------|---------|-------------|
| Pixel Regular | Clean monospace  | 62     | `#39FF14` Neon Green | Crisp, readable, classic pixel font |
| Pixel Bold    | Thick strokes    | 62     | `#00D4FF` Neon Cyan  | Heavy weight for headings and emphasis |
| Pixel Script  | Hand-drawn feel  | 62     | `#FF2D9B` Neon Pink  | Irregular, organic stroke style |
| **Total**     |                  | **186**|         | |

Each glyph: A-Z (26) + a-z (26) + 0-9 (10) = 62 characters per font.

## File Structure

```
pixel-font-pack/
├── README.md              <- You are here
├── USAGE.md               <- Integration guides (Godot, Unity, Web)
├── LICENSE                <- MIT License
├── src/
│   ├── font_data.json     <- Master font metadata
│   ├── generate_font.py   <- Python SVG generator (stdlib only)
│   └── charsets/
│       ├── regular.json   <- 8x8 glyph bitmaps for Pixel Regular
│       ├── bold.json      <- 8x8 glyph bitmaps for Pixel Bold
│       └── handwritten.json <- 8x8 glyph bitmaps for Pixel Script
├── preview/
│   └── index.html         <- Static font specimen gallery
├── demo/
│   └── index.html         <- Interactive type-and-preview demo
└── examples/
```

## Quick Start

1. Open `preview/index.html` to see the full character set for all 3 fonts
2. Open `demo/index.html` to type text and see it rendered in pixel fonts
3. Run `python3 src/generate_font.py` to generate SVG glyph files

## Generate SVGs

```bash
cd src/
python3 generate_font.py
# Outputs individual glyph SVGs and combined specimen sheets
```

## Color Palette

| Color | Hex | Usage |
|-------|-----|-------|
| Background | `#0a0a12` | Dark void background |
| Regular Font | `#39FF14` | Neon green — Pixel Regular glyphs |
| Bold Font | `#00D4FF` | Neon cyan — Pixel Bold glyphs |
| Handwritten Font | `#FF2D9B` | Neon pink — Pixel Script glyphs |
| Grid Line | `#1a1a2e` | Subtle grid overlay |
| Highlight | `#ffffff` | White accent for specimens |

## Font Properties

| Property | Value |
|----------|-------|
| Glyph Size | 8x8 pixels |
| Grid Unit | 1px per cell |
| Format | SVG (rect elements) |
| Spacing | 1px between glyphs |
| Baseline | Row 7 (0-indexed) |
| Cap Height | Rows 1-6 (uppercase) |
| x-Height | Rows 3-6 (lowercase) |
| Supported Characters | `A-Z a-z 0-9` |
| Characters Per Font | 62 |
| Total Glyphs | 186 |
| Python Dependency | stdlib only (xml.etree.ElementTree) |

## License

MIT License — use in personal and commercial projects. See LICENSE file.
