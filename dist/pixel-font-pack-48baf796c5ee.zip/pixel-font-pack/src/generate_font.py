#!/usr/bin/env python3
"""
Pixel Font Pack Generator — Pixel Forge
Generates 8×8 pixel font glyphs as SVG pixel art.

Each glyph is defined as an 8×8 binary grid. Outputs individual SVG files
per glyph, combined specimen sheets per font, and a master sheet.

Usage:
    python3 generate_font.py
"""

import json
import os
import xml.etree.ElementTree as ET


# ─── Palette ──────────────────────────────────────────────────────────────────
PALETTE = {
    "background": "#0a0a12",
    "regular":    "#39FF14",
    "bold":       "#00D4FF",
    "handwritten":"#FF2D9B",
    "grid":       "#1a1a2e",
    "highlight":  "#ffffff",
}

GRID_SIZE = 8
PIXEL_SIZE = 8  # Each "pixel" is 8x8 SVG units


def load_charset(path: str) -> dict:
    """Load a charset JSON file and return the glyphs dict."""
    with open(path, "r") as f:
        data = json.load(f)
    return data["glyphs"]


def load_font_data(path: str) -> dict:
    """Load the master font_data.json."""
    with open(path, "r") as f:
        return json.load(f)


def glyph_to_svg(
    glyph_rows: list,
    color: str,
    name: str = "glyph",
    bg_color: str = None,
    pixel_size: int = PIXEL_SIZE,
) -> str:
    """Convert an 8×8 binary glyph to an SVG string using xml.etree."""
    width = GRID_SIZE * pixel_size
    height = GRID_SIZE * pixel_size

    svg = ET.Element("svg")
    svg.set("xmlns", "http://www.w3.org/2000/svg")
    svg.set("viewBox", f"0 0 {width} {height}")
    svg.set("width", str(width))
    svg.set("height", str(height))
    svg.set("shape-rendering", "crispEdges")

    title = ET.SubElement(svg, "title")
    title.text = name

    # Background
    if bg_color:
        bg = ET.SubElement(svg, "rect")
        bg.set("width", str(width))
        bg.set("height", str(height))
        bg.set("fill", bg_color)

    # Glyph pixels
    for y, row in enumerate(glyph_rows):
        for x, pixel in enumerate(row):
            if pixel == "1":
                rect = ET.SubElement(svg, "rect")
                rect.set("x", str(x * pixel_size))
                rect.set("y", str(y * pixel_size))
                rect.set("width", str(pixel_size))
                rect.set("height", str(pixel_size))
                rect.set("fill", color)

    return ET.tostring(svg, encoding="unicode", xml_declaration=False)


def create_specimen_sheet(
    glyphs: dict,
    color: str,
    font_name: str,
    columns: int = 16,
    pixel_size: int = PIXEL_SIZE,
    padding: int = 2,
) -> str:
    """Create a combined specimen sheet SVG with all glyphs in a grid."""
    glyph_names = sorted(glyphs.keys(), key=lambda c: (
        0 if c.isupper() else (1 if c.islower() else 2), c
    ))
    cell_size = GRID_SIZE * pixel_size + padding * pixel_size
    rows = (len(glyph_names) + columns - 1) // columns
    sheet_w = columns * cell_size
    sheet_h = rows * cell_size

    # Header space
    header_h = 4 * pixel_size
    total_h = header_h + sheet_h

    svg = ET.Element("svg")
    svg.set("xmlns", "http://www.w3.org/2000/svg")
    svg.set("viewBox", f"0 0 {sheet_w} {total_h}")
    svg.set("width", str(sheet_w))
    svg.set("height", str(total_h))
    svg.set("shape-rendering", "crispEdges")

    title = ET.SubElement(svg, "title")
    title.text = f"{font_name} — Specimen Sheet"

    # Background
    bg = ET.SubElement(svg, "rect")
    bg.set("width", str(sheet_w))
    bg.set("height", str(total_h))
    bg.set("fill", PALETTE["background"])

    # Title text (as pixel rects would be complex, use SVG text)
    txt = ET.SubElement(svg, "text")
    txt.set("x", str(pixel_size))
    txt.set("y", str(3 * pixel_size))
    txt.set("fill", color)
    txt.set("font-family", "monospace")
    txt.set("font-size", str(2.5 * pixel_size))
    txt.text = font_name

    # Glyphs
    for idx, char in enumerate(glyph_names):
        col = idx % columns
        row = idx // columns
        ox = col * cell_size
        oy = header_h + row * cell_size

        glyph_rows = glyphs[char]
        g = ET.SubElement(svg, "g")
        g.set("id", f"glyph-{ord(char):04x}")
        g.set("transform", f"translate({ox},{oy})")

        # Cell background (subtle grid)
        cell_bg = ET.SubElement(g, "rect")
        cell_bg.set("width", str(GRID_SIZE * pixel_size))
        cell_bg.set("height", str(GRID_SIZE * pixel_size))
        cell_bg.set("fill", PALETTE["grid"])

        # Pixels
        for y, row_data in enumerate(glyph_rows):
            for x, pixel in enumerate(row_data):
                if pixel == "1":
                    rect = ET.SubElement(g, "rect")
                    rect.set("x", str(x * pixel_size))
                    rect.set("y", str(y * pixel_size))
                    rect.set("width", str(pixel_size))
                    rect.set("height", str(pixel_size))
                    rect.set("fill", color)

        # Character label below
        label = ET.SubElement(g, "text")
        label.set("x", str(GRID_SIZE * pixel_size // 2))
        label.set("y", str(GRID_SIZE * pixel_size + padding * pixel_size - 2))
        label.set("fill", PALETTE["highlight"])
        label.set("font-family", "monospace")
        label.set("font-size", str(pixel_size))
        label.set("text-anchor", "middle")
        label.text = char

    return ET.tostring(svg, encoding="unicode", xml_declaration=False)


def safe_filename(char: str) -> str:
    """Create a safe filename for a character."""
    if char.isupper():
        return f"upper_{char}"
    elif char.islower():
        return f"lower_{char}"
    elif char.isdigit():
        return f"digit_{char}"
    else:
        return f"char_{ord(char):04x}"


def main() -> None:
    """Generate all pixel font SVGs."""
    base_dir = os.path.dirname(os.path.abspath(__file__))
    font_data_path = os.path.join(base_dir, "font_data.json")
    font_data = load_font_data(font_data_path)

    print("=" * 60)
    print("  Pixel Font Pack Generator — Pixel Forge")
    print("=" * 60)

    for font_key, font_info in font_data["fonts"].items():
        font_name = font_info["name"]
        color = font_info["color"]
        charset_path = os.path.join(base_dir, font_info["charset_file"])
        sheet_file = font_info["sheet_file"]

        print(f"\n─── {font_name} ({font_key}) ───")
        print(f"  Color: {color}")
        print(f"  Charset: {font_info['charset_file']}")

        glyphs = load_charset(charset_path)
        glyph_count = len(glyphs)
        print(f"  Glyphs loaded: {glyph_count}")

        # Create output directory for individual glyphs
        glyph_dir = os.path.join(base_dir, font_key)
        os.makedirs(glyph_dir, exist_ok=True)

        # Generate individual glyph SVGs
        for char, glyph_rows in glyphs.items():
            svg_str = glyph_to_svg(
                glyph_rows,
                color=color,
                name=f"{font_name} - {char}",
                bg_color=PALETTE["background"],
            )
            filename = safe_filename(char)
            path = os.path.join(glyph_dir, f"{filename}.svg")
            with open(path, "w") as f:
                f.write(svg_str)

        print(f"  Individual SVGs: {glyph_count} files -> {font_key}/")

        # Generate specimen sheet
        specimen_svg = create_specimen_sheet(
            glyphs, color=color, font_name=font_name
        )
        specimen_path = os.path.join(base_dir, sheet_file)
        with open(specimen_path, "w") as f:
            f.write(specimen_svg)
        print(f"  Specimen sheet: {sheet_file}")

    # Generate master combined sheet with all fonts
    print("\n─── Master Specimen ───")
    master_parts = []
    total_height = 0
    font_sheets = []

    for font_key, font_info in font_data["fonts"].items():
        charset_path = os.path.join(base_dir, font_info["charset_file"])
        glyphs = load_charset(charset_path)
        font_sheets.append({
            "name": font_info["name"],
            "color": font_info["color"],
            "glyphs": glyphs,
        })

    # Build combined master sheet
    columns = 16
    pixel_size = PIXEL_SIZE
    padding = 2
    cell_size = GRID_SIZE * pixel_size + padding * pixel_size
    section_header = 4 * pixel_size
    sheet_w = columns * cell_size

    total_h = 0
    for sheet in font_sheets:
        glyph_count = len(sheet["glyphs"])
        rows = (glyph_count + columns - 1) // columns
        total_h += section_header + rows * cell_size

    master_svg = ET.Element("svg")
    master_svg.set("xmlns", "http://www.w3.org/2000/svg")
    master_svg.set("viewBox", f"0 0 {sheet_w} {total_h}")
    master_svg.set("width", str(sheet_w))
    master_svg.set("height", str(total_h))
    master_svg.set("shape-rendering", "crispEdges")

    master_title = ET.SubElement(master_svg, "title")
    master_title.text = "Pixel Font Pack — Master Specimen"

    master_bg = ET.SubElement(master_svg, "rect")
    master_bg.set("width", str(sheet_w))
    master_bg.set("height", str(total_h))
    master_bg.set("fill", PALETTE["background"])

    y_offset = 0
    for sheet in font_sheets:
        font_name = sheet["name"]
        color = sheet["color"]
        glyphs = sheet["glyphs"]

        # Section title
        txt = ET.SubElement(master_svg, "text")
        txt.set("x", str(pixel_size))
        txt.set("y", str(y_offset + 3 * pixel_size))
        txt.set("fill", color)
        txt.set("font-family", "monospace")
        txt.set("font-size", str(2.5 * pixel_size))
        txt.text = font_name

        y_offset += section_header

        glyph_names = sorted(glyphs.keys(), key=lambda c: (
            0 if c.isupper() else (1 if c.islower() else 2), c
        ))

        for idx, char in enumerate(glyph_names):
            col = idx % columns
            row = idx // columns
            ox = col * cell_size
            oy = y_offset + row * cell_size

            glyph_rows = glyphs[char]
            g = ET.SubElement(master_svg, "g")
            g.set("transform", f"translate({ox},{oy})")

            cell_bg = ET.SubElement(g, "rect")
            cell_bg.set("width", str(GRID_SIZE * pixel_size))
            cell_bg.set("height", str(GRID_SIZE * pixel_size))
            cell_bg.set("fill", PALETTE["grid"])

            for gy, row_data in enumerate(glyph_rows):
                for gx, pixel in enumerate(row_data):
                    if pixel == "1":
                        rect = ET.SubElement(g, "rect")
                        rect.set("x", str(gx * pixel_size))
                        rect.set("y", str(gy * pixel_size))
                        rect.set("width", str(pixel_size))
                        rect.set("height", str(pixel_size))
                        rect.set("fill", color)

        glyph_count = len(glyph_names)
        rows = (glyph_count + columns - 1) // columns
        y_offset += rows * cell_size

    master_path = os.path.join(base_dir, "all_fonts_specimen.svg")
    with open(master_path, "w") as f:
        f.write(ET.tostring(master_svg, encoding="unicode", xml_declaration=False))
    print(f"  Master sheet: all_fonts_specimen.svg")

    print(f"\n{'=' * 60}")
    print(f"  Done! Generated SVGs for {len(font_data['fonts'])} fonts")
    print(f"  Total glyphs: {font_data['pack']['total_glyphs']}")
    print(f"{'=' * 60}")


if __name__ == "__main__":
    main()
