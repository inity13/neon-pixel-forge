# 👾 Monster Bestiary Pack

**30 animated pixel art monsters for RPGs, roguelikes, and action games. Each creature is 32×32 with idle and attack animations, complete with stats and hitbox data.**

## What's Included

| Monster | Type | Animations | Description |
|---------|------|------------|-------------|
| Green Slime | Common | idle, attack, death | Classic bouncing blob |
| Skeleton Warrior | Common | idle, attack, death | Sword-wielding undead |
| Fire Bat | Common | idle, attack, death | Winged flame creature |
| Ice Golem | Elite | idle, attack, death | Frozen stone giant |
| Shadow Wraith | Elite | idle, attack, death | Dark spectral entity |
| Dragon Boss | Boss | idle, attack, death | Fire-breathing wyrm |

## Color Palette

| Color | Hex | Usage |
|-------|-----|-------|
| Outline | `#1a1a2e` | Dark outlines |
| Slime Green | `#2ecc71` | Slime body light |
| Slime Dark | `#1a9c54` | Slime body shadow |
| Bone White | `#f0e6d0` | Skeleton bones |
| Bone Shadow | `#c8b898` | Bone shading |
| Fire Orange | `#ff6b35` | Fire/flame effects |
| Fire Yellow | `#ffb347` | Fire highlights |
| Ice Blue | `#74b9ff` | Ice golem body |
| Ice Dark | `#3d7bc9` | Ice shading |
| Shadow Purple | `#6c5ce7` | Wraith body |
| Shadow Dark | `#4a3ab5` | Wraith shadow |
| Dragon Red | `#e74c3c` | Dragon scales |
| Dragon Dark | `#a93226` | Dragon shadow |
| Eye Red | `#ff0000` | Glowing eyes |
| Eye Yellow | `#f1c40f` | Boss eyes |

## File Structure

```
monster-bestiary-pack/
├── README.md
├── USAGE.md
├── LICENSE
├── palette.json
├── src/
│   ├── generate_monsters.py  ← SVG generator for all monsters
│   └── monster_data.json     ← Stats, animations, hitboxes
├── preview/
│   └── index.html            ← Visual monster catalog
└── demo/
    └── index.html            ← Interactive battle encounter
```

## Animation Data Format

```json
{
  "green_slime": {
    "animations": {
      "idle": { "frames": [0, 1], "frame_duration_ms": 400, "loop": true },
      "attack": { "frames": [2, 3], "frame_duration_ms": 200, "loop": false },
      "death": { "frames": [4, 5], "frame_duration_ms": 300, "loop": false }
    },
    "hitbox": { "x": 4, "y": 8, "width": 24, "height": 24 }
  }
}
```

## License
MIT — see LICENSE file.
