#!/usr/bin/env python3
"""
Monster Bestiary Generator — Pixel Forge
Generates SVG pixel art for 6 monsters at 32×32 resolution.

Each "pixel" is a colored SVG <rect> element with crisp rendering.
Uses only Python stdlib. No external dependencies.

Usage:
    python3 generate_monsters.py
    # Outputs SVG files to current directory
"""

import json
import os
from typing import Optional

# ─── Color Palette ────────────────────────────────────────────────────────────
PALETTE = {
    "_": None,            # transparent
    "O": "#1a1a2e",       # outline
    "g": "#2ecc71",       # slime light
    "G": "#1a9c54",       # slime dark
    "w": "#ffffff",       # white (eyes)
    "b": "#f0e6d0",       # bone light
    "B": "#c8b898",       # bone dark
    "m": "#8a9ab0",       # metal
    "f": "#ff6b35",       # fire orange
    "F": "#ffb347",       # fire yellow
    "d": "#cc4400",       # fire dark
    "i": "#a8d8ff",       # ice light
    "I": "#74b9ff",       # ice mid
    "J": "#3d7bc9",       # ice dark
    "s": "#8b7ceb",       # shadow light
    "S": "#6c5ce7",       # shadow mid
    "P": "#4a3ab5",       # shadow dark
    "r": "#ef6f5c",       # dragon light
    "R": "#e74c3c",       # dragon mid
    "D": "#a93226",       # dragon dark
    "y": "#f5c56a",       # dragon belly
    "E": "#ff0000",       # eye red
    "Y": "#f1c40f",       # eye yellow
    "K": "#000000",       # pure black
}

# ─── Monster Pixel Data (32×32 each) ─────────────────────────────────────────

SLIME_IDLE = [
    "________________________________",
    "________________________________",
    "________________________________",
    "________________________________",
    "________________________________",
    "________________________________",
    "________________________________",
    "________________________________",
    "________________________________",
    "________________________________",
    "____________OOOOOOOO____________",
    "__________OOggggggggOO__________",
    "_________OgggggggggggO__________",
    "________OggggggggggggggO________",
    "________OggwwOggggwwOggO________",
    "________OggwwOggggwwOggO________",
    "________OggggggggggggggO________",
    "_______OgggggggggggggggO________",
    "_______OggggggGGggggggggO_______",
    "_______OgggGGGGGGGGgggggO______",
    "______OgggGGGGGGGGGGggggO______",
    "______OggGGGGGGGGGGGGgggO______",
    "______OgGGGGGGGGGGGGGGggO______",
    "_____OGGGGGGGGGGGGGGGGGGO_______",
    "_____OOOOOOOOOOOOOOOOOOO________",
    "________________________________",
    "________________________________",
    "________________________________",
    "________________________________",
    "________________________________",
    "________________________________",
    "________________________________",
]

SLIME_ATTACK = [
    "________________________________",
    "________________________________",
    "________________________________",
    "________________________________",
    "________________________________",
    "________________________________",
    "________________________________",
    "________________________________",
    "__________OOOOOOOOOO____________",
    "________OOggggggggggOO__________",
    "_______OgggggggggggggO__________",
    "______OggggggggggggggggO________",
    "______OggwwOggggggwwOggO________",
    "______OggwwOggggggwwOggO________",
    "______OgggggggOOggggggO_________",
    "_____OggggggOggggOggggO_________",
    "_____OgggggggggggggggggO________",
    "_____OgggggggGGggggggggO________",
    "____OggggGGGGGGGGGgggggO_______",
    "____OgggGGGGGGGGGGGggggO_______",
    "____OggGGGGGGGGGGGGGgggO_______",
    "___OgGGGGGGGGGGGGGGGGgO________",
    "___OGGGGGGGGGGGGGGGGGGO_________",
    "___OOOOOOOOOOOOOOOOOOO__________",
    "________________________________",
    "________________________________",
    "________________________________",
    "________________________________",
    "________________________________",
    "________________________________",
    "________________________________",
    "________________________________",
]

SKELETON_IDLE = [
    "________________________________",
    "________________________________",
    "____________OOOOO_______________",
    "___________ObbbbBO______________",
    "__________ObbbbbbBO_____________",
    "__________ObEObBEbO_____________",
    "__________ObbbbbbBO_____________",
    "__________ObObbObBO_____________",
    "___________ObbbbO_______________",
    "____________ObBO________________",
    "___________OOOOO________________",
    "__________ObbBbbO________________",
    "_________ObbOBObbO______________",
    "_________ObOOBOObO______________",
    "________ObbO_B_ObbO_____________",
    "________ObO__B__ObO_____________",
    "_________OO_OBO_OO______________",
    "____________ObBO_________________",
    "____________ObBO_________________",
    "____________OBBO_________________",
    "____________ObBO_________________",
    "____________ObBO_________________",
    "___________ObbBbO_______________",
    "__________ObbO_ObO______________",
    "_________ObbO___ObO_____________",
    "_________ObO_____bO_____________",
    "_________OO______OO_____________",
    "________________________________",
    "________________________________",
    "________________________________",
    "________________________________",
    "________________________________",
]

SKELETON_ATTACK = [
    "________________________________",
    "________________________________",
    "____________OOOOO_______________",
    "___________ObbbbBO______________",
    "__________ObbbbbbBO_____________",
    "__________ObEObBEbO_____________",
    "__________ObbbbbbBO_____________",
    "__________ObObbObBO_____________",
    "___________ObbbbO_______________",
    "____________ObBO________________",
    "___________OOOOO________________",
    "__________ObbBbbO________________",
    "_OmmmO__ObbOBObbO_______________",
    "_OmmmO_ObbOOBOObO_______________",
    "__OmOOObbO__B__ObO______________",
    "___OObbO____B___OO______________",
    "____OO_____OBO___OO_____________",
    "____________ObBO_________________",
    "____________ObBO_________________",
    "____________OBBO_________________",
    "____________ObBO_________________",
    "____________ObBO_________________",
    "___________ObbBbO_______________",
    "__________ObbO_ObO______________",
    "_________ObbO___ObO_____________",
    "_________ObO_____bO_____________",
    "_________OO______OO_____________",
    "________________________________",
    "________________________________",
    "________________________________",
    "________________________________",
    "________________________________",
]

FIRE_BAT_IDLE = [
    "________________________________",
    "________________________________",
    "________________________________",
    "________________________________",
    "________________________________",
    "________________________________",
    "________________________________",
    "___Of____OOOO____fO_____________",
    "__Off___OffffO___ffO____________",
    "_Offf__OfffffO__fffO____________",
    "OffFf_OffffffO_fFffO___________",
    "OfFFfOffffffffOfFFfO___________",
    "OFFFfOffffEEffOfFFFO___________",
    "_OFFfOffffffffOFFfO____________",
    "__OfOOOffffffOOOfO_____________",
    "____OddffffffdO________________",
    "_____OddffffdO_________________",
    "______OddddddO_________________",
    "_______OOOOOO___________________",
    "________________________________",
    "________________________________",
    "________________________________",
    "________________________________",
    "________________________________",
    "________________________________",
    "________________________________",
    "________________________________",
    "________________________________",
    "________________________________",
    "________________________________",
    "________________________________",
    "________________________________",
]

FIRE_BAT_ATTACK = [
    "________________________________",
    "________________________________",
    "________________________________",
    "________________________________",
    "___Of______________fO___________",
    "__Off______________ffO__________",
    "_Offf____OOOO____fffO___________",
    "OffFf___OffffO___fFffO__________",
    "OfFFf__OfffffO__fFFfO___________",
    "OFFFf_OffffffO_fFFFO___________",
    "_OFFfOffffffffOfFFfO____________",
    "__OfOOffffEEffOOfO______________",
    "____OdffffffffdO________________",
    "_____OdffffffdO_________________",
    "______OffffffO___FFF____________",
    "_______OddddO__FFFFF___________",
    "________OOOO__FFFFFFF__________",
    "______________OFFFffO___________",
    "_______________OfffO____________",
    "________________OOO_____________",
    "________________________________",
    "________________________________",
    "________________________________",
    "________________________________",
    "________________________________",
    "________________________________",
    "________________________________",
    "________________________________",
    "________________________________",
    "________________________________",
    "________________________________",
    "________________________________",
]

ICE_GOLEM_IDLE = [
    "________________________________",
    "____________OOOOOO______________",
    "___________OIIIIIiO_____________",
    "__________OIIJJJIIiO____________",
    "__________OIJEOJEIiO____________",
    "__________OIJJJJJIiO____________",
    "__________OIIJJJIIiO____________",
    "___________OIIIIiO______________",
    "___________OIIIIIO______________",
    "__________OIIJJIIIIO____________",
    "_________OIIIJJIIIiO____________",
    "________OIIIIJJIIIIiO___________",
    "________OIIIIJJIIIIiO___________",
    "_______OJIIIIJJIIIIJiO__________",
    "______OJJIIIIJJIIIIJJiO_________",
    "______OJJIIIIIIIIIIJJiO_________",
    "______OJJJIIIIIIIIJJJiO_________",
    "_______OJJIIIIIIIIJJiO__________",
    "________OIIIIIIIIIIiO___________",
    "________OIIIJJJJIIIiO___________",
    "________OIIJJOOJJIIiO___________",
    "_______OIIIJJOOJJIIiO___________",
    "_______OIIIJJOOJJIIIiO__________",
    "_______OIIJJO__OJJIIiO__________",
    "______OIIJJO____OJJIiO__________",
    "______OIIJJO____OJJIiO__________",
    "______OIIJJO____OJJIiO__________",
    "______OOJJO______OJJOO__________",
    "_______OOO________OOO___________",
    "________________________________",
    "________________________________",
    "________________________________",
]

ICE_GOLEM_ATTACK = [
    "________________________________",
    "____________OOOOOO______________",
    "___________OIIIIIiO_____________",
    "__________OIIJJJIIiO____________",
    "__________OIJEOJEIiO____________",
    "__________OIJJJJJIiO____________",
    "__________OIIJJJIIiO____________",
    "___________OIIIIiO______________",
    "___________OIIIIIO______________",
    "__________OIIJJIIIIO____________",
    "_________OIIIJJIIIiO____________",
    "________OIIIIJJIIIIiO___________",
    "OOOOO__OIIIIJJIIIIiO___________",
    "OiiiiOOJIIIIJJIIIIJiO__________",
    "OiIIIOJJIIIIJJIIIIJJiO_________",
    "_OIIOJJIIIIIIIIIIIIJJO___________",
    "__OIOJJJIIIIIIIIIJJJiO__________",
    "___OOOJJIIIIIIIIIJJiO___________",
    "________OIIIIIIIIIIiO___________",
    "________OIIIJJJJIIIiO___________",
    "________OIIJJOOJJIIiO___________",
    "_______OIIIJJOOJJIIiO___________",
    "_______OIIIJJOOJJIIIiO__________",
    "_______OIIJJO__OJJIIiO__________",
    "______OIIJJO____OJJIiO__________",
    "______OIIJJO____OJJIiO__________",
    "______OIIJJO____OJJIiO__________",
    "______OOJJO______OJJOO__________",
    "_______OOO________OOO___________",
    "________________________________",
    "________________________________",
    "________________________________",
]

SHADOW_WRAITH_IDLE = [
    "________________________________",
    "________________________________",
    "________________________________",
    "___________OOOOOOO______________",
    "__________OSSSSSSsO_____________",
    "_________OSSPPPPSSsO____________",
    "_________OSPEOPEOSsO____________",
    "_________OSSPPPPSSsO____________",
    "__________OSSSSSSsO_____________",
    "___________OSSSsO_______________",
    "_________OOSSSSSSsOO____________",
    "________OSSSSSSSSSSsO___________",
    "_______OSSSSSSSSSSSsO___________",
    "______OPSSSSSSSSSSSSsO__________",
    "______OPSSSSSSSSSSSSsO__________",
    "_____OPPSSSSSSSSSSSSPsO_________",
    "_____OPPSSSSSSSSSSSPPsO_________",
    "______OPSSSSSSSSSSSPsO__________",
    "_______OSSSSSSSSSSSSsO__________",
    "________OSSSSSSSSSSsO___________",
    "_________OSSSSSSSSSsO___________",
    "__________OSSSSSSPsO____________",
    "___________OSSSPPsO_____________",
    "____________OPPPsO______________",
    "_____________OPsO_______________",
    "______________OO_________________",
    "________________________________",
    "________________________________",
    "________________________________",
    "________________________________",
    "________________________________",
    "________________________________",
]

SHADOW_WRAITH_ATTACK = [
    "________________________________",
    "________________________________",
    "________________________________",
    "___________OOOOOOO______________",
    "__________OSSSSSSsO_____________",
    "_________OSSPPPPSSsO____________",
    "_________OSPEOPEOSsO____________",
    "_________OSSPPPPSSsO____________",
    "__________OSSSSSSsO_____________",
    "___________OSSSsO_______________",
    "_________OOSSSSSSsOO____________",
    "________OSSSSSSSSSSsO___________",
    "_______OSSSSSSSSSSSsO___________",
    "OSSO__OPSSSSSSSSSSSSsO__OSSO____",
    "OSSSOOPSSSSSSSSSSSSsOOOSSO_____",
    "OPSSSOPSSSSSSSSSSSPPSOSSPsO____",
    "_OPSSOPSSSSSSSSSSSPSOSSPsO_____",
    "__OSOOPSSSSSSSSSSSSSOOSPO_______",
    "___OO__OSSSSSSSSSSsO_OO_________",
    "_________OSSSSSSSSSsO___________",
    "__________OSSSSSSPsO____________",
    "___________OSSSPPsO_____________",
    "____________OPPPsO______________",
    "_____________OPsO_______________",
    "______________OO_________________",
    "________________________________",
    "________________________________",
    "________________________________",
    "________________________________",
    "________________________________",
    "________________________________",
    "________________________________",
]

DRAGON_IDLE = [
    "________________________________",
    "______OOOOO_____________________",
    "_____ORRRRrO____________________",
    "____ORRYOYRrO___________________",
    "____ORRRRRRrO___________________",
    "____ORRDDRRrO___________________",
    "_____ORRRRrO____________________",
    "_____ORRRRrO_______OO___________",
    "______ORRrO______OrrO___________",
    "______ORRrO____OrrRrO___________",
    "______ORRDrOOOrrRRRrO___________",
    "______ORRDDrrRRRRRRrO___________",
    "_____ORRRDDyyyRRRRrO____________",
    "____ORRRRDyyyyyRRRrO____________",
    "____ORRRRDyyyyyRRRrO____________",
    "____ORRRRDyyyyyRRRrO____________",
    "_____ORRRDyyyRRRRrO_____________",
    "______ORRDDRRRRRRrO_____________",
    "_______ORRDRRRRRrO______________",
    "________ORRRRRRrO_______________",
    "________ORRRRRRrO_______________",
    "________ORROORR rO_______________",
    "_______ORROo__ORRrO______________",
    "_______ORRO____ORrO_____________",
    "______ORRDO____ODRrO____________",
    "______ORRDO____ODRrO____________",
    "______OODO______ODOO____________",
    "_______OO________OO_____________",
    "________________________________",
    "________________________________",
    "________________________________",
    "________________________________",
]

DRAGON_ATTACK = [
    "________________________________",
    "______OOOOO_____________________",
    "_____ORRRRrO____________________",
    "____ORRYOYRrO___________________",
    "____ORRRRRRrO__FFFFF____________",
    "____ORRRRRRrOFFfFFFF____________",
    "_____ORRRRrOFffffFFF____________",
    "_____ORRRRrOfffffffFF___________",
    "______ORRrOOfffffffF____________",
    "______ORRrO__OFFFFF_____________",
    "______ORRDrOOOrrRRRrO___________",
    "______ORRDDrrRRRRRRrO___________",
    "_____ORRRDDyyyRRRRrO____________",
    "____ORRRRDyyyyyRRRrO____________",
    "____ORRRRDyyyyyRRRrO____________",
    "____ORRRRDyyyyyRRRrO____________",
    "_____ORRRDyyyRRRRrO_____________",
    "______ORRDDRRRRRRrO_____________",
    "_______ORRDRRRRRrO______________",
    "________ORRRRRRrO_______________",
    "________ORRRRRRrO_______________",
    "________ORROORRrO_______________",
    "_______ORROo__ORRrO______________",
    "_______ORRO____ORrO_____________",
    "______ORRDO____ODRrO____________",
    "______ORRDO____ODRrO____________",
    "______OODO______ODOO____________",
    "_______OO________OO_____________",
    "________________________________",
    "________________________________",
    "________________________________",
    "________________________________",
]

# ─── All Sprites ──────────────────────────────────────────────────────────────
SPRITES: dict[str, dict] = {
    "slime_idle": {"data": SLIME_IDLE, "label": "Green Slime (Idle)", "monster": "green_slime"},
    "slime_attack": {"data": SLIME_ATTACK, "label": "Green Slime (Attack)", "monster": "green_slime"},
    "skeleton_idle": {"data": SKELETON_IDLE, "label": "Skeleton (Idle)", "monster": "skeleton_warrior"},
    "skeleton_attack": {"data": SKELETON_ATTACK, "label": "Skeleton (Attack)", "monster": "skeleton_warrior"},
    "bat_idle": {"data": FIRE_BAT_IDLE, "label": "Fire Bat (Idle)", "monster": "fire_bat"},
    "bat_attack": {"data": FIRE_BAT_ATTACK, "label": "Fire Bat (Attack)", "monster": "fire_bat"},
    "golem_idle": {"data": ICE_GOLEM_IDLE, "label": "Ice Golem (Idle)", "monster": "ice_golem"},
    "golem_attack": {"data": ICE_GOLEM_ATTACK, "label": "Ice Golem (Attack)", "monster": "ice_golem"},
    "wraith_idle": {"data": SHADOW_WRAITH_IDLE, "label": "Shadow Wraith (Idle)", "monster": "shadow_wraith"},
    "wraith_attack": {"data": SHADOW_WRAITH_ATTACK, "label": "Shadow Wraith (Attack)", "monster": "shadow_wraith"},
    "dragon_idle": {"data": DRAGON_IDLE, "label": "Dragon Boss (Idle)", "monster": "dragon_boss"},
    "dragon_attack": {"data": DRAGON_ATTACK, "label": "Dragon Boss (Attack)", "monster": "dragon_boss"},
}


def pixel_data_to_svg(name: str, rows: list[str], scale: int = 4) -> str:
    """Convert pixel data rows to an SVG string."""
    height = len(rows)
    width = max(len(row) for row in rows) if rows else 0
    svg_w = width * scale
    svg_h = height * scale

    parts: list[str] = [
        f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 {svg_w} {svg_h}"',
        f'     width="{svg_w}" height="{svg_h}"',
        '     shape-rendering="crispEdges">',
        f"  <title>{name}</title>",
    ]

    for y, row in enumerate(rows):
        for x, ch in enumerate(row):
            color = PALETTE.get(ch)
            if color is None:
                continue
            parts.append(
                f'  <rect x="{x * scale}" y="{y * scale}" '
                f'width="{scale}" height="{scale}" fill="{color}"/>'
            )

    parts.append("</svg>")
    return "\n".join(parts)


def generate_all_svgs(output_dir: str = ".") -> dict:
    """Generate SVG files for every monster sprite."""
    os.makedirs(output_dir, exist_ok=True)
    manifest: dict = {}

    for name, info in SPRITES.items():
        rows = info["data"]
        svg_content = pixel_data_to_svg(info["label"], rows, scale=4)
        filename = f"{name}.svg"
        filepath = os.path.join(output_dir, filename)

        with open(filepath, "w", encoding="utf-8") as f:
            f.write(svg_content)

        height = len(rows)
        width = max(len(row) for row in rows) if rows else 0

        manifest[name] = {
            "file": filename,
            "label": info["label"],
            "monster": info["monster"],
            "width_px": width,
            "height_px": height,
        }
        print(f"  ✓ {filename} ({width}×{height}px)")

    return manifest


if __name__ == "__main__":
    script_dir = os.path.dirname(os.path.abspath(__file__))
    output_dir = script_dir

    print("Monster Bestiary Generator")
    print("=" * 40)
    print(f"Output: {output_dir}\n")

    print("Generating monster SVGs...")
    manifest = generate_all_svgs(output_dir)

    manifest_path = os.path.join(output_dir, "manifest.json")
    with open(manifest_path, "w", encoding="utf-8") as f:
        json.dump(manifest, f, indent=2)
    print(f"\n  ✓ manifest.json")
    print(f"\nDone! Generated {len(manifest)} sprites.")
