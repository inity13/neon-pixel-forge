#!/usr/bin/env python3
"""
Pixel Weapons Generator — Pixel Forge
Generates 32×32 weapon sprites as SVG pixel art.

Each weapon is defined as a 32×32 character grid. Includes swords, axes,
bows, staffs, guns, and shields across 5 rarity tiers.

Usage:
    python3 generate_weapons.py
"""

import json
import os
from typing import Optional

PALETTE = {
    "_": None,           # transparent
    "O": "#1a1a2e",      # outline
    "i": "#808890",      # iron
    "I": "#505860",      # iron dark
    "S": "#a0a8b0",      # steel
    "s": "#b0b8c0",      # steel light
    "W": "#6b4226",      # wood handle
    "w": "#8b6246",      # wood light
    "L": "#5a3a1e",      # leather wrap
    "R": "#cc3030",      # gem red
    "B": "#3060cc",      # gem blue
    "G": "#30a030",      # gem green
    "b": "#e0d8c0",      # bone
    # Rarity glows
    "1": "#808080",      # common glow
    "2": "#2ecc71",      # uncommon glow
    "3": "#3498db",      # rare glow
    "4": "#9b59b6",      # epic glow
    "5": "#f1c40f",      # legendary glow
}

# ─── Weapon Pixel Data (32×32 each) ──────────────────────────────────────────
WEAPONS = {
    "iron_sword": {
        "rarity": "common",
        "type": "sword",
        "description": "A basic iron sword. Reliable and affordable.",
        "stats": {"damage": 8, "speed": 1.0, "range": 1},
        "pixels": [
            "________________________________",
            "________________________________",
            "_____________________________Os_",
            "____________________________OsO_",
            "___________________________OsO__",
            "__________________________OsO___",
            "_________________________OsO____",
            "________________________OsO_____",
            "_______________________OiO______",
            "______________________OiO_______",
            "_____________________OiO________",
            "____________________OiO_________",
            "___________________OiO__________",
            "__________________OiO___________",
            "_________________OiO____________",
            "________________OiO_____________",
            "_______________OiO______________",
            "______________OiO_______________",
            "_____________OiO________________",
            "____________OiO_________________",
            "___________OIO__________________",
            "__________OIO___________________",
            "_________OWO____________________",
            "________OWWO____________________",
            "_______OOLWLOO__________________",
            "________OWWO____________________",
            "_________OWO____________________",
            "__________OWO___________________",
            "___________OO___________________",
            "________________________________",
            "________________________________",
            "________________________________",
        ],
    },
    "fire_blade": {
        "rarity": "rare",
        "type": "sword",
        "description": "A blade forged in dragonfire. Burns with eternal flame.",
        "stats": {"damage": 22, "speed": 0.9, "range": 1},
        "pixels": [
            "________________________________",
            "____________________________R3__",
            "___________________________R33R_",
            "__________________________R3O3__",
            "_________________________R3Os___",
            "________________________R_OsO___",
            "_________________________OsO____",
            "________________________OsO_____",
            "_______________________OsO______",
            "______________________OiO_______",
            "_____________________OiO________",
            "____________________OiO_________",
            "___________________OiO__________",
            "__________________OiO___________",
            "_________________OiO____________",
            "________________OiO_____________",
            "_______________OiO______________",
            "______________OiO_______________",
            "_____________OiO________________",
            "____________OiO_________________",
            "___________OIO__________________",
            "__________OIO___________________",
            "_________ORWO___________________",
            "________OWRWO___________________",
            "_______OOLRLOO__________________",
            "________OWRWO___________________",
            "_________OWO____________________",
            "__________OWO___________________",
            "___________OO___________________",
            "________________________________",
            "________________________________",
            "________________________________",
        ],
    },
    "battle_axe": {
        "rarity": "common",
        "type": "axe",
        "description": "A sturdy double-headed battle axe.",
        "stats": {"damage": 12, "speed": 0.7, "range": 1},
        "pixels": [
            "________________________________",
            "________________________________",
            "________________________________",
            "________OOO______OOO___________",
            "_______OIIIO____OIIIO__________",
            "______OIiiiIO__OIiiiIO_________",
            "_____OIiiiiIOOOIiiiiIO_________",
            "_____OIiiiiIiiiIiiiiIO_________",
            "______OIiiiIiiiIiiiIO__________",
            "_______OOOOIiiiIOOOO___________",
            "____________OiiiO______________",
            "____________OiiiO______________",
            "____________OWWWO______________",
            "____________OWWWO______________",
            "____________OWWWO______________",
            "____________OLLLO______________",
            "____________OWWWO______________",
            "____________OWWWO______________",
            "____________OLLLO______________",
            "____________OWWWO______________",
            "____________OWWWO______________",
            "____________OWWWO______________",
            "____________OLLLO______________",
            "____________OWWWO______________",
            "____________OWWWO______________",
            "____________OWWWO______________",
            "_____________OOO_______________",
            "________________________________",
            "________________________________",
            "________________________________",
            "________________________________",
            "________________________________",
        ],
    },
    "short_bow": {
        "rarity": "common",
        "type": "bow",
        "description": "A light wooden short bow for quick shots.",
        "stats": {"damage": 6, "speed": 1.2, "range": 5},
        "pixels": [
            "________________________________",
            "________________________________",
            "________________________________",
            "________________________________",
            "___________OO___________________",
            "__________OWWO__________________",
            "_________OW__WO_________________",
            "________OW____WO________________",
            "_______OW______WO_______________",
            "______OW_______WOOOOOO__________",
            "_____OW________LLLLLLO__________",
            "____OW_________WOOOOOO__________",
            "____OW________WO________________",
            "____OW_______WO_________________",
            "_____OW_____WO__________________",
            "______OW___WO___________________",
            "_______OW_WO____________________",
            "________OWWO____________________",
            "_________OO_____________________",
            "________________________________",
            "________________________________",
            "________________________________",
            "________________________________",
            "________________________________",
            "________________________________",
            "________________________________",
            "________________________________",
            "________________________________",
            "________________________________",
            "________________________________",
            "________________________________",
            "________________________________",
        ],
    },
    "lightning_staff": {
        "rarity": "epic",
        "type": "staff",
        "description": "Channels raw lightning. Crackles with purple energy.",
        "stats": {"damage": 28, "speed": 0.6, "range": 4},
        "pixels": [
            "________________________________",
            "___________O44O_________________",
            "__________O4444O________________",
            "__________O4BB4O________________",
            "__________O4BB4O________________",
            "__________O4444O________________",
            "___________OWWO_________________",
            "___________OWWO_________________",
            "___________OWWO_________________",
            "___________O44O_________________",
            "___________OWWO_________________",
            "___________OWWO_________________",
            "___________OWWO_________________",
            "___________OWWO_________________",
            "___________O44O_________________",
            "___________OWWO_________________",
            "___________OWWO_________________",
            "___________OWWO_________________",
            "___________OWWO_________________",
            "___________OWWO_________________",
            "___________O44O_________________",
            "___________OWWO_________________",
            "___________OWWO_________________",
            "___________OWWO_________________",
            "___________OWWO_________________",
            "___________OWWO_________________",
            "___________OWWO_________________",
            "____________OO__________________",
            "________________________________",
            "________________________________",
            "________________________________",
            "________________________________",
        ],
    },
    "plasma_pistol": {
        "rarity": "uncommon",
        "type": "gun",
        "description": "A compact plasma sidearm with a glowing green charge.",
        "stats": {"damage": 14, "speed": 1.1, "range": 6},
        "pixels": [
            "________________________________",
            "________________________________",
            "________________________________",
            "________________________________",
            "________________________________",
            "________________________________",
            "________________________________",
            "________________________________",
            "________________________________",
            "________________________________",
            "______OOOOOOOOOOOOOO____________",
            "_____OIIIIIIIIIIIiiO____________",
            "____OIiiiiiiiiiiiiiO2O__________",
            "____OIiiiiiiiiiiiiO2O___________",
            "____OIiiiiiiiiiiiiOO____________",
            "____OIiiOOOOiiiiIO_____________",
            "____OIiiOWWOiiiiIO_____________",
            "_____OOOOWWOiiiIO______________",
            "________OWWOOIIO_______________",
            "________OWWO_OO________________",
            "________OWWO____________________",
            "_________OO_____________________",
            "________________________________",
            "________________________________",
            "________________________________",
            "________________________________",
            "________________________________",
            "________________________________",
            "________________________________",
            "________________________________",
            "________________________________",
            "________________________________",
        ],
    },
    "tower_shield": {
        "rarity": "uncommon",
        "type": "shield",
        "description": "A tall iron shield covering head to knee.",
        "stats": {"defense": 15, "weight": 8, "block_chance": 0.6},
        "pixels": [
            "________________________________",
            "________________________________",
            "________________________________",
            "________________________________",
            "________OOOOOOOOOOOO____________",
            "_______OiiiiiiiiiiiiO___________",
            "______OiSSSSSSSSSSSSiO__________",
            "______OiSSSSSSSSSSSSiO__________",
            "______OiSS2SSSSS2SSiO__________",
            "______OiSSSSSSSSSSSSiO__________",
            "______OiSSSSSSSSSSSSiO__________",
            "______OiSS2SSSSS2SSiO__________",
            "______OiSSSSSSSSSSSSiO__________",
            "______OiSSSSSSSSSSSSiO__________",
            "______OiSSSSSSSSSSSSiO__________",
            "______OiSS2SSSSS2SSiO__________",
            "______OiSSSSSSSSSSSSiO__________",
            "______OiSSSSSSSSSSSSiO__________",
            "______OiSSSSSSSSSSSSiO__________",
            "______OiSSSSSSSSSSSSiO__________",
            "______OiSSSSSSSSSSSSiO__________",
            "______OiSSSSSSSSSSSSiO__________",
            "_______OiiiiiiiiiiiiO___________",
            "________OOOOOOOOOOOO____________",
            "________________________________",
            "________________________________",
            "________________________________",
            "________________________________",
            "________________________________",
            "________________________________",
            "________________________________",
            "________________________________",
        ],
    },
}


def pixel_data_to_svg(pixels: list[str], pixel_size: int = 8, name: str = "weapon") -> str:
    """Convert pixel data to SVG."""
    w = len(pixels[0]) * pixel_size
    h = len(pixels) * pixel_size
    parts = [
        f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 {w} {h}" '
        f'width="{w}" height="{h}" shape-rendering="crispEdges">',
        f"  <title>{name}</title>",
    ]
    for y, row in enumerate(pixels):
        for x, c in enumerate(row):
            color = PALETTE.get(c)
            if not color:
                continue
            parts.append(
                f'  <rect x="{x*pixel_size}" y="{y*pixel_size}" '
                f'width="{pixel_size}" height="{pixel_size}" fill="{color}"/>'
            )
    parts.append("</svg>")
    return "\n".join(parts)


def main() -> None:
    out = os.path.dirname(os.path.abspath(__file__))

    # Individual weapon SVGs
    for name, data in WEAPONS.items():
        svg = pixel_data_to_svg(data["pixels"], name=name)
        path = os.path.join(out, f"{name}.svg")
        with open(path, "w") as f:
            f.write(svg)
        print(f"  {name}.svg ({data['rarity']} {data['type']})")

    # Weapons data JSON (without pixel data for lightweight import)
    weapons_meta = {}
    for name, data in WEAPONS.items():
        weapons_meta[name] = {
            "rarity": data["rarity"],
            "type": data["type"],
            "description": data["description"],
            "stats": data["stats"],
        }
    path = os.path.join(out, "weapons_data.json")
    with open(path, "w") as f:
        json.dump(weapons_meta, f, indent=2)
    print(f"\n  weapons_data.json ({len(WEAPONS)} weapons)")

    # Combined sheet SVG
    cols = 4
    items = list(WEAPONS.items())
    sprite_w = 32 * 8
    sprite_h = 32 * 8
    rows = (len(items) + cols - 1) // cols
    sheet_w = cols * sprite_w
    sheet_h = rows * sprite_h

    parts = [
        f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 {sheet_w} {sheet_h}" '
        f'width="{sheet_w}" height="{sheet_h}" shape-rendering="crispEdges">',
        "<title>Pixel Weapons Collection</title>",
    ]
    for idx, (wname, wdata) in enumerate(items):
        col = idx % cols
        row = idx // cols
        ox = col * sprite_w
        oy = row * sprite_h
        parts.append(f'  <g id="{wname}" transform="translate({ox},{oy})">')
        for y, prow in enumerate(wdata["pixels"]):
            for x, c in enumerate(prow):
                color = PALETTE.get(c)
                if not color:
                    continue
                parts.append(
                    f'    <rect x="{x*8}" y="{y*8}" width="8" height="8" fill="{color}"/>'
                )
        parts.append("  </g>")
    parts.append("</svg>")

    path = os.path.join(out, "weapons_sheet.svg")
    with open(path, "w") as f:
        f.write("\n".join(parts))
    print(f"  weapons_sheet.svg (combined)")


if __name__ == "__main__":
    main()
