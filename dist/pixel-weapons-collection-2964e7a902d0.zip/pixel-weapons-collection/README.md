# ⚔️ Pixel Weapons Collection

**100+ pixel art weapons in 32×32 format, ready for game inventory systems.**

```
  ╔══════╦══════╦══════╦══════╦══════╦══════╗
  ║ 🗡️    ║ 🪓    ║ 🏹    ║ 🪄    ║ 🔫    ║ 🛡️    ║
  ║SWORDS ║ AXES ║ BOWS ║STAFFS║ GUNS ║SHIELD║
  ║  20   ║  15  ║  12  ║  15  ║  18  ║  20  ║
  ╚══════╩══════╩══════╩══════╩══════╩══════╝
            Weapon Categories (100+ total)
```

## What's Included

| Category | Count | Examples |
|----------|-------|---------|
| Swords | 20 | Rusty sword, iron blade, fire sword, ice saber, legendary katana |
| Axes | 15 | Hatchet, battle axe, double axe, crystal axe, demon cleaver |
| Bows | 12 | Short bow, longbow, crossbow, enchanted bow, shadow bow |
| Staffs | 15 | Wooden staff, fire staff, ice staff, lightning rod, elder wand |
| Guns | 18 | Pistol, shotgun, laser gun, plasma rifle, ray blaster |
| Shields | 20 | Buckler, tower shield, magic barrier, dragon scale, void shield |
| **Total** | **100** | All with transparent backgrounds |

## File Structure

```
pixel-weapons-collection/
├── README.md
├── USAGE.md
├── palette.json           ← 5 rarity-tier color schemes
├── src/
│   ├── weapons_sheet.svg  ← All weapons on one sheet
│   ├── weapons_data.json  ← Stats, rarity, descriptions per weapon
│   ├── generate_weapons.py ← SVG generator (stdlib)
│   └── generate_ppm.py    ← PPM output (stdlib)
├── preview/
│   └── index.html         ← Visual weapon catalog with filters
├── demo/
│   └── index.html         ← Drag-and-drop inventory demo
└── examples/
    └── inventory_system.md ← How to build an inventory UI
```

## Rarity Tiers

Each weapon has a rarity tier affecting its color accent:

| Tier | Color | Hex | Drop Rate |
|------|-------|-----|-----------|
| Common | Gray | `#808080` | 50% |
| Uncommon | Green | `#2ecc71` | 25% |
| Rare | Blue | `#3498db` | 15% |
| Epic | Purple | `#9b59b6` | 8% |
| Legendary | Gold | `#f1c40f` | 2% |

## License

MIT License — see LICENSE file.
