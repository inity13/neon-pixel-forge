#!/usr/bin/env python3
"""
Sci-Fi UI Kit Generator — Pixel Forge
Generates SVG pixel art UI components with a futuristic theme.

Each "pixel" is a colored SVG <rect> element with crisp rendering.
Components include health bars, energy bars, inventory slots, buttons,
dialog boxes, minimap frames, and more.

Uses only Python stdlib. No external dependencies.

Usage:
    python3 generate_ui.py
    # Outputs SVG files + component data JSON to current directory
"""

import json
import os
from typing import Optional

# ─── Color Palette ────────────────────────────────────────────────────────────
PALETTE = {
    "_": None,            # transparent
    "D": "#0a1628",       # panel dark
    "M": "#162040",       # panel mid
    "L": "#203060",       # panel light
    "B": "#30a0ff",       # border (cyan)
    "G": "#60c0ff",       # border glow
    "R": "#ff3030",       # health red
    "r": "#ff6060",       # health highlight
    "C": "#30ffcc",       # energy cyan
    "c": "#60ffd8",       # energy highlight
    "U": "#304080",       # button bg
    "u": "#405090",       # button hover
    "T": "#e0e8ff",       # text primary
    "t": "#6080a0",       # text secondary
    "W": "#ffaa00",       # warning orange
    "E": "#ff3030",       # error red
    "S": "#30ff60",       # success green
    "Y": "#f1c40f",       # gold/credits
    "K": "#000000",       # pure black (shadows)
}


# ─── UI Component Pixel Data ─────────────────────────────────────────────────
# Each component is drawn as pixel art rows. Character → palette color.
# Components are drawn at their native pixel size.

# --- Health Bar (64×8) ---
HEALTH_BAR_FULL = [
    "_BBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBB_",
    "BDRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRDB",
    "BDrRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRDB",
    "BDrRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRDB",
    "BDRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRDB",
    "BDRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRDB",
    "BDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDB",
    "_BBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBB_",
]

HEALTH_BAR_HALF = [
    "_BBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBB_",
    "BDRRRRRRRRRRRRRRRRRRRRRRRRRRRRRDDDDDDDDDDDDDDDDDDDDDDDDDDDDDb",
    "BDrRRRRRRRRRRRRRRRRRRRRRRRRRRRRDDDDDDDDDDDDDDDDDDDDDDDDDDDDDB",
    "BDrRRRRRRRRRRRRRRRRRRRRRRRRRRRRDDDDDDDDDDDDDDDDDDDDDDDDDDDDDB",
    "BDRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDB",
    "BDRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDB",
    "BDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDB",
    "_BBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBB_",
]

# --- Energy Bar (64×8) ---
ENERGY_BAR_FULL = [
    "_BBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBB_",
    "BDCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCDb",
    "BDcCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCDB",
    "BDcCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCDB",
    "BDCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCDB",
    "BDCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCDB",
    "BDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDB",
    "_BBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBB_",
]

# --- Inventory Slot (32×32) ---
INVENTORY_SLOT_EMPTY = [
    "_BBBBBBBBBBBBBBBBBBBBBBBBBBBBBB_",
    "BMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMB",
    "BMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMB",
    "BMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMB",
    "BMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMB",
    "BMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMB",
    "BMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMB",
    "BMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMB",
    "BMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMB",
    "BMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMB",
    "BMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMB",
    "BMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMB",
    "BMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMB",
    "BMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMB",
    "BMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMB",
    "BMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMB",
    "BMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMB",
    "BMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMB",
    "BMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMB",
    "BMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMB",
    "BMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMB",
    "BMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMB",
    "BMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMB",
    "BMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMB",
    "BMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMB",
    "BMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMB",
    "BMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMB",
    "BMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMB",
    "BMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMB",
    "BMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMB",
    "BMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMB",
    "_BBBBBBBBBBBBBBBBBBBBBBBBBBBBBB_",
]

INVENTORY_SLOT_SELECTED = [
    "_GGGGGGGGGGGGGGGGGGGGGGGGGGGGGG_",
    "GLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLG",
    "GLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLG",
    "GLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLG",
    "GLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLG",
    "GLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLG",
    "GLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLG",
    "GLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLG",
    "GLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLG",
    "GLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLG",
    "GLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLG",
    "GLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLG",
    "GLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLG",
    "GLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLG",
    "GLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLG",
    "GLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLG",
    "GLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLG",
    "GLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLG",
    "GLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLG",
    "GLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLG",
    "GLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLG",
    "GLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLG",
    "GLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLG",
    "GLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLG",
    "GLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLG",
    "GLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLG",
    "GLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLG",
    "GLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLG",
    "GLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLG",
    "GLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLG",
    "GLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLG",
    "_GGGGGGGGGGGGGGGGGGGGGGGGGGGGGG_",
]

# --- Button Normal (48×16) ---
BUTTON_NORMAL = [
    "__BBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBB__",
    "_BUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUB_",
    "BUuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuUB",
    "BUuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuUB",
    "BUuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuUB",
    "BUuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuUB",
    "BUuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuUB",
    "BUuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuUB",
    "BUuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuUB",
    "BUuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuUB",
    "BUuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuUB",
    "BUuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuUB",
    "BUuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuUB",
    "BUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUuUB",
    "_BUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUB_",
    "__BBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBB__",
]

BUTTON_HOVER = [
    "__GGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGG__",
    "_GuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuG_",
    "GuLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLuG",
    "GuLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLuG",
    "GuLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLuG",
    "GuLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLuG",
    "GuLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLuG",
    "GuLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLuG",
    "GuLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLuG",
    "GuLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLuG",
    "GuLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLuG",
    "GuLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLuG",
    "GuLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLuG",
    "GuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuG",
    "_GuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuG_",
    "__GGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGG__",
]

# --- Dialog Box (64×48) ---
DIALOG_BOX_SMALL = [
    "_BBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBB_",
    "BGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGB",
    "BGMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMGB",
    "BGMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMGB",
    "BGMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMRRMMGB",
    "BGMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMRRMMGB",
    "BGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGB",
    "BDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDB",
    "BDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDB",
    "BDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDB",
    "BDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDB",
    "BDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDB",
    "BDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDB",
    "BDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDB",
    "BDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDB",
    "BDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDB",
    "BDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDB",
    "BDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDB",
    "BDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDB",
    "BDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDB",
    "BDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDB",
    "BDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDB",
    "BDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDB",
    "BDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDB",
    "BDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDB",
    "BDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDB",
    "BDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDB",
    "BDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDB",
    "BDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDB",
    "BDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDB",
    "BDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDB",
    "BDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDB",
    "BDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDB",
    "BDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDB",
    "BDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDB",
    "BDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDB",
    "BDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDB",
    "BDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDB",
    "BDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDB",
    "BDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDB",
    "BDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDB",
    "BDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDB",
    "BDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDB",
    "BDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDB",
    "BDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDB",
    "BDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDB",
    "BBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBB",
    "_BBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBB_",
]

# --- Minimap Frame Round (64×64) ---
MINIMAP_FRAME = [
    "________________________BBBBBBBBBBBBBBBB________________________",
    "____________________BBBBDDDDDDDDDDDDDDBBBB____________________",
    "__________________BBDDDDDDDDDDDDDDDDDDDDDDB B__________________",
    "________________BBDDDDDDDDDDDDDDDDDDDDDDDDDDBB________________",
    "______________BBDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDBB______________",
    "____________BBDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDBB____________",
    "___________BDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDB___________",
    "__________BDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDB__________",
    "_________BDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDB_________",
    "________BDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDB________",
    "_______BDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDB_______",
    "_______BDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDB_______",
    "______BDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDB______",
    "______BDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDB______",
    "_____BDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDB_____",
    "_____BDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDB_____",
    "____BDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDB____",
    "____BDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDB____",
    "____BDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDB____",
    "____BDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDB____",
    "___BDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDB___",
    "___BDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDB___",
    "___BDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDB___",
    "___BDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDB___",
    "BBBBDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDBBB B",
    "BBBBDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDBBB B",
    "BBBBDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDBBB B",
    "BBBBDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDBBB B",
    "BBBBBDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDBBBB",
    "BBBBBDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDBBBB",
    "BBBBBDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDBBBB",
    "BBBBBDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDBBBB",
    "BBBBBDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDBBBB",
    "BBBBBDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDBBBB",
    "BBBBBDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDBBBB",
    "BBBBBDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDBBBB",
    "BBBBDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDBBB B",
    "BBBBDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDBBB B",
    "BBBBDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDBBB B",
    "BBBBDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDBBB B",
    "___BDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDB___",
    "___BDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDB___",
    "___BDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDB___",
    "___BDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDB___",
    "____BDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDB____",
    "____BDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDB____",
    "____BDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDB____",
    "____BDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDB____",
    "_____BDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDB_____",
    "_____BDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDB_____",
    "______BDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDB______",
    "______BDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDB______",
    "_______BDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDB_______",
    "_______BDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDB_______",
    "________BDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDB________",
    "_________BDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDB_________",
    "__________BDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDB__________",
    "___________BDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDB___________",
    "____________BBDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDBB____________",
    "______________BBDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDBB______________",
    "________________BBDDDDDDDDDDDDDDDDDDDDDDDDDDBB________________",
    "__________________BBDDDDDDDDDDDDDDDDDDDDDDBB__________________",
    "____________________BBBBDDDDDDDDDDDDDDBBBB____________________",
    "________________________BBBBBBBBBBBBBBBB________________________",
]


# ─── All Components Registry ─────────────────────────────────────────────────
COMPONENTS: dict[str, dict] = {
    "health_bar_full": {
        "data": HEALTH_BAR_FULL,
        "label": "Health Bar (Full)",
        "category": "bars",
    },
    "health_bar_half": {
        "data": HEALTH_BAR_HALF,
        "label": "Health Bar (50%)",
        "category": "bars",
    },
    "energy_bar_full": {
        "data": ENERGY_BAR_FULL,
        "label": "Energy Bar (Full)",
        "category": "bars",
    },
    "inventory_slot_empty": {
        "data": INVENTORY_SLOT_EMPTY,
        "label": "Inventory Slot (Empty)",
        "category": "inventory",
    },
    "inventory_slot_selected": {
        "data": INVENTORY_SLOT_SELECTED,
        "label": "Inventory Slot (Selected)",
        "category": "inventory",
    },
    "button_normal": {
        "data": BUTTON_NORMAL,
        "label": "Button (Normal)",
        "category": "buttons",
    },
    "button_hover": {
        "data": BUTTON_HOVER,
        "label": "Button (Hover)",
        "category": "buttons",
    },
    "dialog_box_small": {
        "data": DIALOG_BOX_SMALL,
        "label": "Dialog Box",
        "category": "panels",
    },
    "minimap_frame": {
        "data": MINIMAP_FRAME,
        "label": "Minimap Frame",
        "category": "panels",
    },
}


def pixel_data_to_svg(name: str, rows: list[str], scale: int = 4) -> str:
    """Convert pixel data rows to an SVG string.

    Args:
        name: Component name for the SVG title element.
        rows: List of strings where each character maps to PALETTE.
        scale: Size of each pixel in SVG units. Default 4.

    Returns:
        Complete SVG document as a string.
    """
    height = len(rows)
    width = max(len(row) for row in rows) if rows else 0
    svg_w = width * scale
    svg_h = height * scale

    parts: list[str] = [
        f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 {svg_w} {svg_h}"',
        f'     width="{svg_w}" height="{svg_h}"',
        '     shape-rendering="crispEdges">',
        f"  <title>{name}</title>",
    ]

    for y, row in enumerate(rows):
        for x, ch in enumerate(row):
            color = PALETTE.get(ch)
            if color is None:
                continue
            parts.append(
                f'  <rect x="{x * scale}" y="{y * scale}" '
                f'width="{scale}" height="{scale}" fill="{color}"/>'
            )

    parts.append("</svg>")
    return "\n".join(parts)


def generate_all_svgs(output_dir: str = ".") -> dict:
    """Generate SVG files for every UI component.

    Args:
        output_dir: Directory to write SVG files into.

    Returns:
        Dictionary mapping component names to their file paths and dimensions.
    """
    os.makedirs(output_dir, exist_ok=True)
    manifest: dict = {}

    for name, info in COMPONENTS.items():
        rows = info["data"]
        svg_content = pixel_data_to_svg(info["label"], rows, scale=4)
        filename = f"{name}.svg"
        filepath = os.path.join(output_dir, filename)

        with open(filepath, "w", encoding="utf-8") as f:
            f.write(svg_content)

        height = len(rows)
        width = max(len(row) for row in rows) if rows else 0

        manifest[name] = {
            "file": filename,
            "label": info["label"],
            "category": info["category"],
            "width_px": width,
            "height_px": height,
        }
        print(f"  ✓ {filename} ({width}×{height}px)")

    return manifest


def generate_combined_sheet(output_dir: str = ".") -> None:
    """Generate a single combined SVG with all UI components arranged in a grid.

    Components are laid out in rows with padding between them.
    Useful for visual reference and sprite sheet extraction.

    Args:
        output_dir: Directory to write the combined SVG file.
    """
    scale = 4
    padding = 16  # pixels between components
    max_row_width = 600  # max width before wrapping

    # Lay out components
    x_cursor = padding
    y_cursor = padding
    row_height = 0
    rects: list[str] = []
    labels: list[str] = []

    for name, info in COMPONENTS.items():
        rows = info["data"]
        h = len(rows)
        w = max(len(row) for row in rows) if rows else 0
        comp_w = w * scale
        comp_h = h * scale

        # Wrap to next row if needed
        if x_cursor + comp_w + padding > max_row_width and x_cursor > padding:
            x_cursor = padding
            y_cursor += row_height + padding + 20  # +20 for label space
            row_height = 0

        # Add label
        labels.append(
            f'<text x="{x_cursor}" y="{y_cursor - 4}" '
            f'font-family="monospace" font-size="10" fill="#e0e8ff">'
            f"{info['label']}</text>"
        )

        # Render pixels
        for py, row in enumerate(rows):
            for px, ch in enumerate(row):
                color = PALETTE.get(ch)
                if color is None:
                    continue
                rects.append(
                    f'<rect x="{x_cursor + px * scale}" '
                    f'y="{y_cursor + py * scale}" '
                    f'width="{scale}" height="{scale}" fill="{color}"/>'
                )

        x_cursor += comp_w + padding
        row_height = max(row_height, comp_h)

    total_w = max_row_width
    total_h = y_cursor + row_height + padding

    svg = "\n".join([
        f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 {total_w} {total_h}"',
        f'     width="{total_w}" height="{total_h}"',
        '     shape-rendering="crispEdges">',
        f'  <rect width="{total_w}" height="{total_h}" fill="#050a18"/>',
        "  <!-- Labels -->",
        "\n".join(labels),
        "  <!-- Component Pixels -->",
        "\n".join(rects),
        "</svg>",
    ])

    filepath = os.path.join(output_dir, "ui_kit_sheet.svg")
    with open(filepath, "w", encoding="utf-8") as f:
        f.write(svg)
    print(f"  ✓ ui_kit_sheet.svg (combined sheet)")


if __name__ == "__main__":
    script_dir = os.path.dirname(os.path.abspath(__file__))
    output_dir = script_dir

    print("Sci-Fi UI Kit Generator")
    print("=" * 40)
    print(f"Output: {output_dir}\n")

    print("Generating individual SVGs...")
    manifest = generate_all_svgs(output_dir)

    print("\nGenerating combined sheet...")
    generate_combined_sheet(output_dir)

    # Write manifest
    manifest_path = os.path.join(output_dir, "manifest.json")
    with open(manifest_path, "w", encoding="utf-8") as f:
        json.dump(manifest, f, indent=2)
    print(f"\n  ✓ manifest.json")

    print(f"\nDone! Generated {len(manifest)} components.")
