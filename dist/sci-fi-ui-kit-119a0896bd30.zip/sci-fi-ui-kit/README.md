# 🚀 Sci-Fi UI Kit

**Complete pixel art game UI elements with a futuristic sci-fi theme. Health bars, mana bars, inventory slots, buttons, dialog boxes, minimap frames, and more.**

## What's Included

| Component | Variants | Description |
|-----------|----------|-------------|
| Health Bars | 5 sizes | Horizontal bars with segment fills and glow effects |
| Energy/Mana Bars | 5 sizes | Cyan energy bars with pulsing animation data |
| Inventory Slots | 4 styles | Empty, selected, locked, equipped states |
| Buttons | 6 types | Normal, hover, pressed, disabled, toggle on/off |
| Dialog Boxes | 3 sizes | Small, medium, large with title bar and close button |
| Minimap Frame | 2 styles | Round and square with border decorations |
| Currency Display | 2 types | Credits counter and gem counter |
| Notification Badges | 3 types | Info, warning, error |
| Tab Panels | 4 states | Active, inactive, hover, disabled |
| Scroll Bars | 2 orientations | Horizontal and vertical with track and thumb |
| **Total** | **40+** | All with consistent sci-fi styling |

## Color Palette (Sci-Fi)

| Color | Hex | Usage |
|-------|-----|-------|
| Panel Dark | `#0a1628` | Deep panel backgrounds |
| Panel Mid | `#162040` | Standard panel fill |
| Panel Light | `#203060` | Highlighted panels |
| Border | `#30a0ff` | Primary border color (cyan) |
| Border Glow | `#60c0ff` | Glowing accents |
| Health | `#ff3030` | Health bar fill |
| Health Low | `#ff6060` | Health bar highlight |
| Energy | `#30ffcc` | Energy/mana bar fill |
| Button | `#304080` | Button background |
| Button Hover | `#405090` | Button hover state |
| Text Primary | `#e0e8ff` | Main text color |
| Text Secondary | `#6080a0` | Subtitle/hint text |
| Warning | `#ffaa00` | Warning indicators |
| Error | `#ff3030` | Error indicators |
| Success | `#30ff60` | Success indicators |
| Gold/Credits | `#f1c40f` | Currency display |

## File Structure

```
sci-fi-ui-kit/
├── README.md
├── USAGE.md
├── LICENSE
├── palette.json
├── src/
│   ├── ui_components.json   ← Component definitions with 9-slice data
│   ├── generate_ui.py       ← SVG generator for all UI elements
│   └── nine_slice_data.json ← 9-slice border definitions for scaling
├── preview/
│   └── index.html           ← Visual component catalog
└── demo/
    └── index.html           ← Interactive UI mockup demo
```

## 9-Slice Scaling

All bordered UI elements include 9-slice data for proper scaling:
```json
{
  "dialog_box": {
    "border_top": 4,
    "border_right": 4,
    "border_bottom": 4,
    "border_left": 4,
    "min_width": 48,
    "min_height": 32
  }
}
```

## License
MIT — see LICENSE file.
