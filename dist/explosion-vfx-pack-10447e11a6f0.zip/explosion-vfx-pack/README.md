# 💥 Explosion VFX Pack

**32×32 animated explosion effects with 6 explosion types and 48 total frames for action games.**

```
   Frame 1     Frame 2     Frame 3     Frame 4     Frame 5     Frame 6
   ________   ________   ________   ________   ________   ________
  |   ░░   | |  ▓▓▓▓  | | ████▓▓ | |▓▓████▓▓| | ▓▓▓▓▓▓ | |  ░░░░  |
  |  ░██░  | | ▓████▓ | |████████| |████████| | ▓▓▓▓▓▓ | |  ░░░░  |
  |   ░░   | |  ▓▓▓▓  | | ▓▓████ | |▓▓████▓▓| |  ▓▓▓▓  | |   ░░   |
   ‾‾‾‾‾‾‾‾   ‾‾‾‾‾‾‾‾   ‾‾‾‾‾‾‾‾   ‾‾‾‾‾‾‾‾   ‾‾‾‾‾‾‾‾   ‾‾‾‾‾‾‾‾
              Explosion Animation Sequence
```

## What's Included

| Effect Type      | Frames | Size  | Description |
|------------------|--------|-------|-------------|
| Fire Explosion   | 8      | 32×32 | Classic orange fireball with expanding ring |
| Plasma Burst     | 8      | 32×32 | Cyan-magenta energy burst for sci-fi |
| Smoke Puff       | 8      | 32×32 | Gray smoke cloud, great for impacts |
| Spark Shower     | 6      | 32×32 | Directional sparks flying outward |
| Energy Ring      | 8      | 32×32 | Expanding ring of energy particles |
| Pixel Shatter    | 8      | 32×32 | Object disintegration into fragments |
| **Total**        | **46** |       | |

## File Structure

```
explosion-vfx-pack/
├── README.md              <- You are here
├── USAGE.md               <- Integration guides (Godot, Unity, Web)
├── LICENSE                 <- MIT License
├── palette.json            <- Color palette (16 colors, fire/energy theme)
├── src/
│   ├── generate_vfx.py    <- Python SVG generator (stdlib only)
│   └── vfx_data.json      <- Animation data (frame sequences, timing)
├── preview/
│   └── index.html         <- Static gallery of all VFX frames
└── demo/
    └── index.html         <- Animated VFX preview with click-to-explode
```

## Quick Start

1. Open `preview/index.html` to see every frame of every explosion type
2. Open `demo/index.html` for an animated preview — click anywhere to trigger explosions
3. Run `python3 src/generate_vfx.py` to regenerate SVG files from pixel data

## Generate SVGs

```bash
cd src/
python3 generate_vfx.py
# Outputs individual frame SVGs and combined sprite sheets
```

## Color Palette

| Color | Hex | Usage |
|-------|-----|-------|
| Transparent | — | Background / empty |
| Outline | `#1a1a2e` | Dark outlines |
| Fire Core | `#ffffff` | White-hot center of explosions |
| Fire Bright | `#fff44f` | Bright yellow fire |
| Fire Mid | `#ff8830` | Orange mid-flame |
| Fire Dark | `#cc3300` | Deep red-orange fire |
| Ember | `#8a1818` | Dying embers, edges |
| Plasma Cyan | `#00ffcc` | Plasma burst core |
| Plasma Blue | `#30a0ff` | Plasma mid-tone |
| Plasma Dark | `#1060a0` | Plasma edges |
| Smoke Light | `#8090a0` | Light smoke |
| Smoke Mid | `#506070` | Mid-tone smoke |
| Smoke Dark | `#2a3a4a` | Dark smoke |
| Spark | `#ffee88` | Flying sparks |
| Energy | `#cc44ff` | Energy ring magenta |
| Glow | `#ff6600` | Ambient glow overlay |

## Animation Timing

Each explosion type in `src/vfx_data.json` specifies:

```json
{
  "fire_explosion": {
    "frames": 8,
    "frame_duration_ms": 60,
    "loop": false,
    "one_shot": true
  }
}
```

- **`loop: false`** — Explosions play once and stop
- **`frame_duration_ms: 60`** — Fast playback (~16 FPS) for snappy effects
- **`one_shot: true`** — Destroy the sprite after the animation completes

## Integration Tips

- Layer explosions on TOP of other sprites — they use transparent backgrounds
- Use `additive` blend mode in your engine for extra brightness (looks great!)
- Combine effects: fire explosion + smoke puff = realistic detonation
- Scale up 2-4× for boss explosions, keep 1× for bullet impacts

## License

MIT License — use in personal and commercial projects. See LICENSE file.
