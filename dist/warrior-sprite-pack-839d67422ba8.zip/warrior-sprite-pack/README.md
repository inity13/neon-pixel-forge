# ⚔️ Warrior Sprite Pack

**32×32 warrior character sprites with full animation sets for 8 directions.**

```
    ╔══════════════════════════════════════════╗
    ║  ██  ██  ██  ██  ██  ██  ██  ██  ██  ██ ║
    ║  IDLE  WALK  WALK  WALK  WALK  ATK  ATK  ║
    ║  ▓▓▓▓  ▓▓▓▓  ▓▓▓▓  ▓▓▓▓  ▓▓▓▓  ▓▓▓▓    ║
    ║  ████  ████  ████  ████  ████  ████      ║
    ║  ░░░░  ░░░░  ░░░░  ░░░░  ░░░░  ░░░░    ║
    ║   ││    /\    /\    /\    /\    /│\      ║
    ╚══════════════════════════════════════════╝
           Warrior Sprite Sheet Layout
```

## What's Included

| Animation | Frames | Directions | Total Sprites |
|-----------|--------|------------|---------------|
| Idle      | 4      | 8          | 32            |
| Walk      | 6      | 8          | 48            |
| Attack    | 6      | 8          | 48            |
| Death     | 8      | 1          | 8             |
| Hit       | 2      | 8          | 16            |
| **Total** |        |            | **152**       |

## File Structure

```
warrior-sprite-pack/
├── README.md              ← You are here
├── USAGE.md               ← Integration guides (Godot, Unity, Web)
├── palette.json           ← Color palette definition (16 colors)
├── src/
│   ├── warrior_sprites.svg       ← Full sprite sheet in SVG format
│   ├── warrior_idle.svg          ← Idle animation frames
│   ├── warrior_walk.svg          ← Walk animation frames  
│   ├── warrior_attack.svg        ← Attack animation frames
│   ├── warrior_death.svg         ← Death animation frames
│   ├── animation_data.json       ← Frame sequences, timing, hitboxes
│   ├── generate_ppm.py           ← Generate PPM images (Python stdlib)
│   └── sprite_sheet_builder.py   ← Combine frames into sprite sheets
├── preview/
│   └── index.html         ← Open in browser to see all sprites
├── demo/
│   └── index.html         ← Interactive HTML5 Canvas demo
└── examples/
    ├── godot_import.gd    ← GDScript sprite import example
    ├── unity_setup.cs      ← Unity C# sprite slice setup
    └── web_animation.html  ← JavaScript Canvas animation loop
```

## Quick Start

### View the Sprites
Open `preview/index.html` in your browser to see all sprite frames in a visual grid.

### Try the Demo
Open `demo/index.html` in your browser for an interactive demo with keyboard controls:
- **Arrow keys** to move the warrior (8-directional)
- **Space** to attack
- **X** to trigger death animation

### Generate PNG-Compatible Images
```bash
cd src/
python3 generate_ppm.py
# Outputs .ppm files in the output/ directory
# Open with any image viewer or convert to PNG with:
# - GIMP: File > Open > select .ppm
# - ImageMagick: convert warrior_idle.ppm warrior_idle.png
# - Online: https://convertio.co/ppm-png/
```

### Use the SVG Files Directly
The SVG files render pixel art using `<rect>` elements (1 rect per pixel). These are:
- Infinitely scalable without blur
- Editable in any SVG editor (Inkscape, Figma, etc.)
- Convertible to PNG at any resolution

## Animation Timing

All animations use the data in `src/animation_data.json`:

```json
{
  "idle": { "frames": 4, "frame_duration_ms": 200, "loop": true },
  "walk": { "frames": 6, "frame_duration_ms": 120, "loop": true },
  "attack": { "frames": 6, "frame_duration_ms": 100, "loop": false },
  "death": { "frames": 8, "frame_duration_ms": 150, "loop": false },
  "hit": { "frames": 2, "frame_duration_ms": 100, "loop": false }
}
```

## Color Palette

This pack uses a carefully chosen 16-color palette (see `palette.json`):

| Color | Hex | Usage |
|-------|-----|-------|
| Outline | `#1a1a2e` | Sprite outlines |
| Skin Light | `#f5cba7` | Skin highlights |
| Skin Mid | `#d4a574` | Skin midtone |
| Skin Shadow | `#a0724e` | Skin shadows |
| Armor Light | `#a8b8c8` | Steel armor highlight |
| Armor Mid | `#7a8a9a` | Steel armor midtone |
| Armor Dark | `#4a5a6a` | Steel armor shadow |
| Armor Accent | `#c8a848` | Gold trim |
| Cape Light | `#c83030` | Red cape |
| Cape Dark | `#8a1818` | Cape shadow |
| Eye | `#2ecc71` | Bright green eye |

## License

MIT License — use in personal and commercial projects. See LICENSE file.
