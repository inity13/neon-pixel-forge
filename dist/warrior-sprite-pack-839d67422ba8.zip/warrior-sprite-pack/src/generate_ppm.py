#!/usr/bin/env python3
"""
PPM Image Generator — Pixel Forge Warrior Sprite Pack

Generates .ppm (Portable Pixmap) images from pixel art data.
PPM is a dead-simple image format that any image viewer can open:
  - GIMP, IrfanView, Paint.NET, macOS Preview, etc.
  - Convert to PNG via ImageMagick: convert sprite.ppm sprite.png

PPM format (P3 = ASCII, P6 = binary):
  P3
  <width> <height>
  <max_color_value>
  <r g b> <r g b> ...

Uses only Python stdlib. No external dependencies.

Usage:
    python3 generate_ppm.py
    # Creates output/ directory with .ppm files
"""

import os
import sys
from typing import Optional

# ─── Color Palette (hex -> RGB tuples) ────────────────────────────────────────
PALETTE_HEX = {
    "_": None,
    "O": "#1a1a2e",
    "1": "#f5cba7",
    "2": "#d4a574",
    "3": "#a0724e",
    "4": "#8b6914",
    "5": "#5c4a1e",
    "6": "#a8b8c8",
    "7": "#7a8a9a",
    "8": "#4a5a6a",
    "9": "#c8a848",
    "A": "#d0d0d0",
    "B": "#808080",
    "C": "#c83030",
    "D": "#8a1818",
    "E": "#2ecc71",
}


def hex_to_rgb(hex_color: str) -> tuple[int, int, int]:
    """Convert '#RRGGBB' hex string to (R, G, B) tuple."""
    h = hex_color.lstrip("#")
    return (int(h[0:2], 16), int(h[2:4], 16), int(h[4:6], 16))


# Pre-compute RGB palette for speed
PALETTE_RGB: dict[str, Optional[tuple[int, int, int]]] = {
    k: hex_to_rgb(v) if v else None
    for k, v in PALETTE_HEX.items()
}

# Background color for transparent pixels in PPM (PPM doesn't support alpha)
BG_COLOR = (48, 48, 64)  # Dark blue-gray, close to the sprite outline color


def pixel_data_to_ppm(
    pixel_rows: list[str],
    scale: int = 4,
    bg_color: tuple[int, int, int] = BG_COLOR,
) -> str:
    """Convert pixel art data to PPM P3 (ASCII) format.

    Args:
        pixel_rows: List of strings, each char is a palette key
        scale: Integer scale factor (1 = native, 4 = 4× upscale)
        bg_color: RGB tuple for transparent pixels

    Returns:
        PPM file content as string
    """
    height = len(pixel_rows)
    width = len(pixel_rows[0]) if pixel_rows else 0
    scaled_w = width * scale
    scaled_h = height * scale

    lines = [
        "P3",
        f"# Pixel Forge — Warrior Sprite Pack",
        f"{scaled_w} {scaled_h}",
        "255",
    ]

    for row in pixel_rows:
        # Build one row of pixels
        pixel_line = []
        for char in row:
            rgb = PALETTE_RGB.get(char)
            if rgb is None:
                rgb = bg_color
            pixel_line.append(rgb)

        # Scale horizontally and repeat vertically
        scaled_line = []
        for rgb in pixel_line:
            scaled_line.extend([rgb] * scale)

        row_str = " ".join(f"{r} {g} {b}" for r, g, b in scaled_line)
        for _ in range(scale):
            lines.append(row_str)

    return "\n".join(lines)


# ─── Sprite Data (same as generate_sprites.py) ───────────────────────────────
# Importing from generate_sprites.py would be cleaner, but we keep this
# self-contained so each script works independently.

WARRIOR_IDLE = [
    "________________________________",
    "________________________________",
    "________________________________",
    "________________________________",
    "____________OOOOOOO_____________",
    "___________O5544455O____________",
    "__________O554444455O___________",
    "__________O544444445O___________",
    "__________O521EO1E25O___________",
    "__________O521111125O___________",
    "___________O5211125O____________",
    "___________O5O1112OO____________",
    "____________OO111OO_____________",
    "_____________O222O______________",
    "____________OOOOOOO_____________",
    "___________O9776779O____________",
    "__________O97766779OO___________",
    "_________O977666779O_O__________",
    "_________O876666678O__O_________",
    "_________O876666678O___O________",
    "_________O8766OO668OO__O________",
    "__________O88OOOO88OOC_O________",
    "___________OOOOOOOOOOCC_________",
    "____________O8OOO8OOCD__________",
    "____________O8O__O8ODDD_________",
    "____________O8O__O8O____________",
    "___________O88O__O88O___________",
    "___________OOOO__OOOO___________",
    "________________________________",
    "________________________________",
    "________________________________",
    "________________________________",
]

WARRIOR_ATTACK = [
    "________________________________",
    "________________________________",
    "________________________________",
    "________________________________",
    "____________OOOOOOO_____________",
    "___________O5544455O____________",
    "__________O554444455O___________",
    "__________O544444445O___________",
    "__________O521EO1E25O___________",
    "__________O521111125O___________",
    "___________O5211125O____________",
    "___________O5O1112OO____________",
    "____________OO111OO_____________",
    "_____________O222O______________",
    "____________OOOOOOO_____________",
    "___________O9776779O____________",
    "__________O97766779OO___________",
    "_________O977666779OOOOOOOAO____",
    "_________O876666678OBBBBBAO_____",
    "_________O876666678OOOOOAO______",
    "_________O8766OO668O____________",
    "__________O88OOOO88O____________",
    "___________OOOOOOOO_____________",
    "____________O8OO8O______________",
    "____________O8OO8O______________",
    "____________O8OO8O______________",
    "___________O88OO88O_____________",
    "___________OOOOOOOO_____________",
    "________________________________",
    "________________________________",
    "________________________________",
    "________________________________",
]


def main() -> None:
    """Generate PPM files for key warrior poses."""
    # Create output directory next to this script
    script_dir = os.path.dirname(os.path.abspath(__file__))
    output_dir = os.path.join(script_dir, "output")
    os.makedirs(output_dir, exist_ok=True)

    sprites = [
        ("warrior_idle", WARRIOR_IDLE),
        ("warrior_attack", WARRIOR_ATTACK),
    ]

    for name, data in sprites:
        # Generate at 4× scale for visibility (128×128 from 32×32)
        ppm_content = pixel_data_to_ppm(data, scale=4)
        filepath = os.path.join(output_dir, f"{name}.ppm")
        with open(filepath, "w", encoding="utf-8") as f:
            f.write(ppm_content)
        print(f"  Created {filepath}")

        # Also generate at 1× native scale
        ppm_native = pixel_data_to_ppm(data, scale=1)
        filepath_native = os.path.join(output_dir, f"{name}_1x.ppm")
        with open(filepath_native, "w", encoding="utf-8") as f:
            f.write(ppm_native)
        print(f"  Created {filepath_native}")

    print(f"\nDone! Generated {len(sprites) * 2} PPM files in {output_dir}")
    print("Open .ppm files with any image viewer (GIMP, Preview, IrfanView)")
    print("Convert to PNG: convert input.ppm output.png (ImageMagick)")


if __name__ == "__main__":
    main()
