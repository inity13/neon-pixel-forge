#!/usr/bin/env python3
"""
Nature Tileset Mega Generator — Pixel Forge
Generates SVG pixel art for 22 outdoor/nature tiles at 16×16 resolution.

Uses only Python stdlib. No external dependencies.

Usage:
    python3 generate_tiles.py
"""

import json
import os

PALETTE = {
    "_": None,
    "g": "#7ec850",    # grass light
    "G": "#5da83a",    # grass mid
    "d": "#3d7a24",    # grass dark
    "w": "#5bc0eb",    # water light
    "W": "#3a9fd5",    # water mid
    "D": "#2480b0",    # water dark
    "p": "#c9a96e",    # dirt light
    "P": "#a0824a",    # dirt mid
    "q": "#7a6030",    # dirt dark
    "s": "#e8d5a0",    # sand
    "S": "#c8b580",    # sand dark
    "n": "#f0f0ff",    # snow
    "N": "#d0d8e8",    # snow mid
    "t": "#6b4423",    # tree trunk
    "T": "#4a2e15",    # tree trunk dark
    "l": "#4cb868",    # leaf light
    "L": "#2d8a4e",    # leaf mid
    "k": "#1a6634",    # leaf dark
    "o": "#a0a0a0",    # stone light
    "O": "#808080",    # stone mid
    "x": "#6a6a6a",    # stone dark
    "r": "#e74c3c",    # flower red
    "b": "#3498db",    # flower blue
    "y": "#f1c40f",    # flower yellow
    "m": "#8a7a6a",    # mountain light
    "M": "#6a5a4a",    # mountain mid
    "h": "#4a3a2a",    # mountain dark
    "e": "#e0e8f0",    # mountain snow
    "u": "#8b6914",    # wood light
    "U": "#5c4a1e",    # wood dark
}

# ─── 16×16 Tile Data ─────────────────────────────────────────────────────────
TILES: dict[str, dict] = {
    "grass_1": {
        "label": "Grass Light",
        "data": [
            "gGgGggGgggGgggGg",
            "GgGggGgGgGggGgGg",
            "gGggGgGgggGgGggG",
            "GgGgGgggGgGgggGg",
            "ggGgggGgGgggGgGg",
            "gGggGgGgggGgGggg",
            "GgGgggggGgGgggGg",
            "ggGgGgGgggGgGgGg",
            "gGgGggGgGgggGggg",
            "GggGgGgggGgGggGg",
            "gGgggGgGgGggGgGg",
            "GgGgGgggGgGgggGg",
            "ggGgggGgggGgGggg",
            "gGggGgGgGgggGgGg",
            "GgGgggggGgGgggGg",
            "gGgGgGgGggGgGgGg",
        ],
    },
    "grass_2": {
        "label": "Grass Medium",
        "data": [
            "GGdGGGgGGdGGGgGG",
            "GgGGdGGGGGdGGGgG",
            "GGGgGGdGGgGGdGGG",
            "dGGGGgGGGGGgGGGd",
            "GGdGGGGdGGGGGgGG",
            "GgGGGgGGGdGGGGGG",
            "GGGdGGGgGGGGdGGg",
            "GGGGGdGGGGgGGGGG",
            "dGGgGGGGdGGGGGdG",
            "GGGGGGgGGGGdGGGG",
            "GGdGGGGGGgGGGGgG",
            "GgGGGdGGGGGGdGGG",
            "GGGgGGGGdGGGGGGd",
            "GGGGGGgGGGGgGGGG",
            "dGGdGGGGGdGGGGgG",
            "GGGGGgGGGGGGdGGG",
        ],
    },
    "grass_3": {
        "label": "Grass Dark",
        "data": [
            "ddGddGddGddGddGd",
            "dGddGddGddGddGdd",
            "GddGddGddGddGddG",
            "ddGdddGddGdddGdd",
            "dGddGddGddGddGdd",
            "GddGddGdddGddGdd",
            "ddGddGddGddGddGd",
            "dGddGdddGddGdddG",
            "GddGddGddGddGddG",
            "ddGdddGddGdddGdd",
            "dGddGddGddGddGdd",
            "GddGddGdddGddGdd",
            "ddGddGddGddGddGd",
            "dGddGdddGddGdddG",
            "GddGddGddGddGddG",
            "ddGddGddGddGddGd",
        ],
    },
    "water_f0": {
        "label": "Water Frame 1",
        "data": [
            "WWwWWWwWWWwWWWwW",
            "WwWWwWWwWWwWWwWW",
            "wWWwWWwWWwWWwWWw",
            "WWwWWDWWwWWDWWwW",
            "WwWWwWWwWWwWWwWW",
            "wWWwWWwWWDWWwWWw",
            "WWDWWwWWwWWwWWDW",
            "WwWWwWWwWWwWWwWW",
            "wWWwWWDWWwWWDWWw",
            "WWwWWwWWwWWwWWwW",
            "WwWWDWWwWWDWWwWW",
            "wWWwWWwWWwWWwWWw",
            "WWwWWwWWDWWwWWwW",
            "WDWWwWWwWWwWWDWW",
            "wWWwWWwWWwWWwWWw",
            "WWwWWDWWwWWDWWwW",
        ],
    },
    "water_f1": {
        "label": "Water Frame 2",
        "data": [
            "wWWwWWwWWwWWwWWw",
            "WWwWWwWWDWWwWWwW",
            "WwWWDWWwWWDWWwWW",
            "wWWwWWwWWwWWwWWw",
            "WWwWWwWWDWWwWWwW",
            "WDWWwWWwWWwWWDWW",
            "wWWwWWwWWwWWwWWw",
            "WWwWWDWWwWWDWWwW",
            "WwWWwWWwWWwWWwWW",
            "wWWwWWwWWDWWwWWw",
            "WWDWWwWWwWWwWWDW",
            "WwWWwWWwWWwWWwWW",
            "wWWwWWDWWwWWDWWw",
            "WWwWWwWWwWWwWWwW",
            "WwWWDWWwWWDWWwWW",
            "wWWwWWwWWwWWwWWw",
        ],
    },
    "water_f2": {
        "label": "Water Frame 3",
        "data": [
            "WwWWwWWwWWwWWwWW",
            "wWWwWWDWWwWWDWWw",
            "WWwWWwWWwWWwWWwW",
            "WwWWDWWwWWDWWwWW",
            "wWWwWWwWWwWWwWWw",
            "WWwWWwWWDWWwWWwW",
            "WDWWwWWwWWwWWDWW",
            "wWWwWWwWWwWWwWWw",
            "WWwWWDWWwWWDWWwW",
            "WwWWwWWwWWwWWwWW",
            "wWWwWWwWWDWWwWWw",
            "WWDWWwWWwWWwWWDW",
            "WwWWwWWwWWwWWwWW",
            "wWWwWWDWWwWWDWWw",
            "WWwWWwWWwWWwWWwW",
            "WwWWDWWwWWDWWwWW",
        ],
    },
    "dirt_1": {
        "label": "Dirt Path",
        "data": [
            "PPpPPqPPpPPqPPpP",
            "PpPPpPPpPPpPPpPP",
            "pPPpPPqPPpPPqPPp",
            "PPqPPpPPpPPpPPqP",
            "PpPPpPPqPPqPPpPP",
            "pPPqPPpPPpPPpPPq",
            "PPpPPpPPqPPpPPpP",
            "PpPPqPPpPPpPPqPP",
            "qPPpPPpPPqPPpPPp",
            "PPpPPqPPpPPpPPpP",
            "PpPPpPPpPPqPPpPP",
            "pPPqPPqPPpPPpPPq",
            "PPpPPpPPpPPqPPpP",
            "PqPPpPPqPPpPPpPP",
            "pPPpPPpPPpPPqPPp",
            "PPqPPqPPpPPpPPqP",
        ],
    },
    "dirt_2": {
        "label": "Dirt Rocky",
        "data": [
            "PPpPPPpPPPpPPPpP",
            "PpPPoPPpPPoPPpPP",
            "pPPooPPpPPooPPpP",
            "PPoPoPpPPoPoPPpP",
            "PpPPoPPPPPoPPpPP",
            "pPPpPPpPPpPPpPPp",
            "PPpPPPpPPPpPPPpP",
            "PpPPpPPoPPpPPpPP",
            "pPPpPPooPPpPPpPP",
            "PPpPPoPoPPpPPPpP",
            "PpPPPoPPPPpPPpPP",
            "pPPpPPpPPpPPpPPp",
            "PPpPPPpPPPpPPPpP",
            "PpPPpPPpPPpPPpPP",
            "pPPoPPpPPoPPpPPp",
            "PPpPPPpPPPpPPPpP",
        ],
    },
    "sand": {
        "label": "Sand",
        "data": [
            "ssSSssSssSssSsSs",
            "sSssSssSssSssSss",
            "ssSssSsSsSssSsSs",
            "SssSsSsSssSssSsS",
            "sSssSssSssSsSsSs",
            "ssSsSsSsSssSssSs",
            "SssSssSsSsSssSsS",
            "sSsSssSsSssSsSss",
            "ssSssSsSsSssSsSs",
            "SsSsSsSssSssSsSS",
            "sSssSssSsSsSssSs",
            "ssSsSsSsSssSssSs",
            "SssSssSsSsSsSsSS",
            "sSsSssSsSssSsSss",
            "ssSssSssSsSssSsS",
            "SsSsSsSssSssSsSs",
        ],
    },
    "snow": {
        "label": "Snow",
        "data": [
            "nnNnnnNnnnNnnnNn",
            "nNnnNnnNnnNnnNnn",
            "NnnNnnNnnNnnNnnN",
            "nnNnnnNnnNnnnNnn",
            "nNnnNnnNnnNnnNnn",
            "NnnnNnNnnnNnNnnN",
            "nnNnnnNnnnNnnnNn",
            "nNnnNnnNnnNnnNnn",
            "NnnNnnNnnNnnNnnN",
            "nnNnnnNnnNnnnNnn",
            "nNnnNnNnnnNnNnnn",
            "NnnnNnnnNnnNnnNN",
            "nnNnnnNnnnNnnnNn",
            "nNnnNnnNnnNnnNnn",
            "NnnNnnNnnNnnNnnN",
            "nnNnnnNnnNnnnNnn",
        ],
    },
    "stone_floor_1": {
        "label": "Cobblestone",
        "data": [
            "oOxxOooOxxOooOxO",
            "OoooOxOoooOxOooO",
            "oOooOxxOooOxxOoO",
            "xxOoOooxOoOooxOo",
            "ooxOoOooxOoOooOx",
            "OooxOoOooxOoOooO",
            "oOooxOoOooxOoOoO",
            "xxOooxOoOooxOxOo",
            "oOxxOooOxxOooOxO",
            "OoooOxOoooOxOooO",
            "oOooOxxOooOxxOoO",
            "xxOoOooxOoOooxOo",
            "ooxOoOooxOoOooOx",
            "OooxOoOooxOoOooO",
            "oOooxOoOooxOoOoO",
            "xxOooxOoOooxOxOo",
        ],
    },
    "stone_floor_2": {
        "label": "Flagstone",
        "data": [
            "oooooOoooooOoooo",
            "ooOooxoooOooxooo",
            "ooxooxoooxooxooo",
            "OOxxOOOOOxxOOOOO",
            "ooooxooooooxoooo",
            "oOooxoooOooxooOo",
            "oxooxoooxooxooox",
            "OOOOOOOOOOOOOxxO",
            "oooooOoooooOoooo",
            "ooOooxoooOooxooo",
            "ooxooxoooxooxooo",
            "OOxxOOOOOxxOOOOO",
            "ooooxooooooxoooo",
            "oOooxoooOooxooOo",
            "oxooxoooxooxooox",
            "OOOOOOOOOOOOOxxO",
        ],
    },
    "tree_trunk": {
        "label": "Tree Trunk",
        "data": [
            "GGGGGGttttGGGGGG",
            "GGGGGGtTttGGGGGG",
            "GGGGGGtTTtGGGGGG",
            "GGGGGGttTtGGGGGG",
            "GGGGGGtTttGGGGGG",
            "GGGGGGtTTtGGGGGG",
            "GGGGGGttTtGGGGGG",
            "GGGGGGtTttGGGGGG",
            "GGGGGGtTTtGGGGGG",
            "GGGGGGttTtGGGGGG",
            "GGGGGGtTttGGGGGG",
            "GGGGGGtTTtGGGGGG",
            "GGGGGttTTttGGGGG",
            "GGGGttTTTTttGGGG",
            "GGGdtTTTTTTtdGGG",
            "GGddTTTTTTTTddGG",
        ],
    },
    "tree_top": {
        "label": "Tree Canopy",
        "data": [
            "____LLLLllll____",
            "___LLLkLlllll___",
            "__LLLkLLllllll__",
            "_LLkLLLLlllllll_",
            "LLLLkLLLllllllll",
            "LkLLLLkLlllllllL",
            "LLLkLLLLlllllkLL",
            "LLLLkLLLllllLLLL",
            "LLLLLkLLlllLkLLL",
            "LLkLLLLLllLLLLLL",
            "LLLLkLLLlLLLkLLL",
            "LLLLLkLLLLLLLLLL",
            "_LLLLLkLLLLkLLL_",
            "__LLLLLLLLkLLL__",
            "___LLLLLLLLLL___",
            "____LLLLLLLL____",
        ],
    },
    "pine_tree": {
        "label": "Pine Tree",
        "data": [
            "GGGGGGGkkGGGGGGG",
            "GGGGGGkLLkGGGGGG",
            "GGGGGkLLLLkGGGGG",
            "GGGGkLLkLLLkGGGG",
            "GGGkLLLkLLLLkGGG",
            "GGkLLLLLkLLLLkGG",
            "GGGGkLLLLkLLkGGG",
            "GGGkLLkLLLLLLkGG",
            "GGkLLLLkLLLLLLkG",
            "GkLLLLLLkLLLLLLk",
            "GGGkLLLLLkLLLkGG",
            "GGkLLLkLLLLLLLkG",
            "GkLLLLLkLLLLLLLk",
            "kLLLLLLLkLLLLLLk",
            "GGGGGGGttGGGGGGG",
            "GGGGGGGttGGGGGGG",
        ],
    },
    "bush": {
        "label": "Bush",
        "data": [
            "GGGGGGGGGGGGGGGG",
            "GGGGGGllllGGGGGG",
            "GGGGGlLLLLlGGGGG",
            "GGGGlLLkLLLlGGGG",
            "GGGlLLkLLLLLlGGG",
            "GGlLLLLkLLkLLlGG",
            "GGlLkLLLLLLkLlGG",
            "GGlLLLkLLkLLLlGG",
            "GGGlLLLLLLLLlGGG",
            "GGGGlLkLLkLlGGGG",
            "GGGGGlLLLLlGGGGG",
            "GGGGGGllllGGGGGG",
            "GGGGGGGGGGGGGGGG",
            "GGGGGGGGGGGGGGGG",
            "GGGGGGGGGGGGGGGG",
            "GGGGGGGGGGGGGGGG",
        ],
    },
    "flowers_red": {
        "label": "Red Flowers",
        "data": [
            "gGgGggGgggGgggGg",
            "GgrGgGgGgGggrGgG",
            "gGrgGgrGgGgrGggG",
            "GgGgGgggGgGgggGg",
            "ggGggrGgGgggGgGg",
            "gGggGgrgggGgrGgg",
            "GgGgggggGgGgrgGg",
            "ggGgGgGgggGgGgGg",
            "gGgGggrGgGggGggg",
            "GggGgGrggGgGggGg",
            "gGgggGgGgGgrGgGg",
            "GgrGgGgggGgGgggG",
            "ggGggrGgggGgrggg",
            "gGggGgGgGgggGgGg",
            "GgrgggggGgrgggGg",
            "gGgGgGgGggGgGgGg",
        ],
    },
    "flowers_blue": {
        "label": "Blue Flowers",
        "data": [
            "gGgGggGgggGgggGg",
            "GgbGgGgGgGggbGgG",
            "gGbgGgbGgGgbGggG",
            "GgGgGgggGgGgggGg",
            "ggGgggGgGgggGbGg",
            "gGggGgbgggGgbGgg",
            "GgGgggggGgGgggGg",
            "ggGgGbGgggGgGgGg",
            "gGgGggbGgGggGggg",
            "GggGgGgggGbGggGg",
            "gGgggGgGgGggGbGg",
            "GgbGgGgggGgGgggG",
            "ggGgggGgggGgbggg",
            "gGggGgbgGgggGgGg",
            "GgGgggggGgbgggGg",
            "gGgGgGgGggGgGgGg",
        ],
    },
    "mountain_base": {
        "label": "Mountain Base",
        "data": [
            "MMMmMMMmMMMmMMMM",
            "MMmMMmMMmMMmMMMm",
            "MmhMMmhMMmhMMmhM",
            "mhMMMmhMMmhMMMmh",
            "hMMMMmhMmhMMMMmh",
            "MMMMMmhMhMMMMMmh",
            "mMMMMmhhhMMMMMmh",
            "hMMMmhhhhMMMMMhh",
            "hhMMmhhhhMMMMmhh",
            "hhMmhhhhhMMMmhhh",
            "hhmhhhhhhMMmhhhh",
            "hhhhhhhhhMmhhhhh",
            "hhhhhhhhhmhhhhhh",
            "hhhhhhhhhhhhhhhh",
            "hhhhhhhhhhhhhhhh",
            "hhhhhhhhhhhhhhhh",
        ],
    },
    "mountain_peak": {
        "label": "Mountain Peak",
        "data": [
            "________________",
            "_______ee_______",
            "______eMMe______",
            "_____eMMmMe_____",
            "____eMMmMmMe____",
            "___eMmMmMmMMe___",
            "__eMmMmhMmMmMe__",
            "_eMmMmhMhMmMmMe_",
            "eMmMmhMmhMmMmMMe",
            "MmMmhMmMhMmMmMMM",
            "mMmhMmMmhMmMmMMm",
            "MmhMmMmMhMmMmMmM",
            "mhMmMmMmhMmMmhMm",
            "hMmMmMmMhMmMmhMh",
            "MmMmMmMmhMmMmhMM",
            "mMmMmMmMhMmMmhMm",
        ],
    },
    "bridge": {
        "label": "Bridge",
        "data": [
            "uUuUuUuUuUuUuUuU",
            "UuUuUuUuUuUuUuUu",
            "uuuuuuuuuuuuuuuu",
            "UUUUUUUUUUUUUUUU",
            "uUuUuUuUuUuUuUuU",
            "UuUuUuUuUuUuUuUu",
            "uUuUuUuUuUuUuUuU",
            "UuUuUuUuUuUuUuUu",
            "uUuUuUuUuUuUuUuU",
            "UuUuUuUuUuUuUuUu",
            "uUuUuUuUuUuUuUuU",
            "UuUuUuUuUuUuUuUu",
            "uuuuuuuuuuuuuuuu",
            "UUUUUUUUUUUUUUUU",
            "uUuUuUuUuUuUuUuU",
            "UuUuUuUuUuUuUuUu",
        ],
    },
    "fence": {
        "label": "Fence",
        "data": [
            "GGGuGGGGGuGGGGGG",
            "GGGuGGGGGuGGGGGG",
            "GGGuGGGGGuGGGGGG",
            "GGGUGGGGGUGGGGGG",
            "uuuuuuuuuuuuuuuu",
            "UUUUUUUUUUUUUUUU",
            "GGGuGGGGGuGGGGGG",
            "GGGuGGGGGuGGGGGG",
            "uuuuuuuuuuuuuuuu",
            "UUUUUUUUUUUUUUUU",
            "GGGuGGGGGuGGGGGG",
            "GGGuGGGGGuGGGGGG",
            "GGGUGGGGGUGGGGGG",
            "GGGGGGGGGGGGGGGG",
            "GGGGGGGGGGGGGGGG",
            "GGGGGGGGGGGGGGGG",
        ],
    },
}


def pixel_data_to_svg(name: str, rows: list[str], scale: int = 4) -> str:
    height = len(rows)
    width = max(len(row) for row in rows) if rows else 0
    svg_w, svg_h = width * scale, height * scale
    parts = [
        f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 {svg_w} {svg_h}"',
        f'     width="{svg_w}" height="{svg_h}" shape-rendering="crispEdges">',
        f'  <title>{name}</title>',
    ]
    for y, row in enumerate(rows):
        for x, ch in enumerate(row):
            color = PALETTE.get(ch)
            if color is None:
                continue
            parts.append(
                f'  <rect x="{x*scale}" y="{y*scale}" '
                f'width="{scale}" height="{scale}" fill="{color}"/>'
            )
    parts.append('</svg>')
    return '\n'.join(parts)


def generate_all(output_dir: str = ".") -> dict:
    os.makedirs(output_dir, exist_ok=True)
    manifest = {}
    for name, info in TILES.items():
        svg = pixel_data_to_svg(info["label"], info["data"], scale=4)
        fname = f"{name}.svg"
        with open(os.path.join(output_dir, fname), "w") as f:
            f.write(svg)
        h = len(info["data"])
        w = max(len(r) for r in info["data"])
        manifest[name] = {"file": fname, "label": info["label"], "width_px": w, "height_px": h}
        print(f"  ✓ {fname} ({w}×{h}px)")
    return manifest


if __name__ == "__main__":
    script_dir = os.path.dirname(os.path.abspath(__file__))
    print("Nature Tileset Mega Generator")
    print("=" * 40)
    manifest = generate_all(script_dir)
    with open(os.path.join(script_dir, "manifest.json"), "w") as f:
        json.dump(manifest, f, indent=2)
    print(f"\nDone! Generated {len(manifest)} tiles.")
