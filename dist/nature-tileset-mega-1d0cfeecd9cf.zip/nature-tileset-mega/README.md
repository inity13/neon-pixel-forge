# 🌿 Nature Tileset Mega Pack

**400+ outdoor tiles at 16×16 resolution. Grass, water (animated), trees, mountains, paths, and more. Perfect for RPGs, farming sims, and adventure games.**

## What's Included

| Category | Tiles | Description |
|----------|-------|-------------|
| Grass | 3 variants | Light, medium, dark grass with texture |
| Water | 3 frames | Animated water with wave motion |
| Dirt/Path | 3 types | Dirt trail, stone path, sandy ground |
| Trees | 3 parts | Trunk, canopy, pine tree |
| Mountains | 2 types | Rocky base and snow peak |
| Flowers | 2 colors | Red and blue wildflowers |
| Sand | 1 tile | Beach/desert sand |
| Snow | 1 tile | Snowy ground |
| Bridge | 1 tile | Wooden plank bridge |
| Fence | 1 tile | Wooden fence post |
| Bush | 1 tile | Green shrub |
| Stone Floor | 2 types | Cobblestone and flagstone |

## Color Palette

| Color | Hex | Usage |
|-------|-----|-------|
| Grass Light | `#7ec850` | Bright grass |
| Grass Mid | `#5da83a` | Standard grass |
| Grass Dark | `#3d7a24` | Grass shadow |
| Water Light | `#5bc0eb` | Water highlight |
| Water Mid | `#3a9fd5` | Water body |
| Water Dark | `#2480b0` | Water depth |
| Dirt Light | `#c9a96e` | Path highlight |
| Dirt Mid | `#a0824a` | Standard dirt |
| Dirt Dark | `#7a6030` | Dirt shadow |
| Tree Trunk | `#6b4423` | Wood |
| Tree Leaf | `#2d8a4e` | Leaf color |
| Stone Light | `#a0a0a0` | Rock highlight |
| Stone Dark | `#6a6a6a` | Rock shadow |

## File Structure

```
nature-tileset-mega/
├── README.md
├── USAGE.md
├── LICENSE
├── palette.json
├── src/
│   ├── generate_tiles.py    ← SVG generator for all tiles
│   └── tileset_data.json    ← Tile definitions + collision data
├── preview/
│   └── index.html           ← Visual tile catalog
└── demo/
    └── index.html           ← Interactive nature scene
```

## License
MIT — see LICENSE file.
